package File_Project;


import Koneksi.konektor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */

/**
 *
 * @author Asus
 */
public class edittable extends javax.swing.JPanel {

    /**
     * Creates new form 
     */
    public edittable() {
            initComponents();
        datatable1();
        datatable2();
        datatable3();
        datatable4();
        datatable5();
        datatable6();
        datatable7();
        datatable8();
        datatable9();
        datapegawai();
        databendahara();
        dataseketaris();
        databendahara1();
        datastaff();
        datastaff1();
        datadirektur();
        datahasillaporan();
        datapegawai1();
        datasurattugas();
        datapegawai2();
    }
    
    
     public void datatable1(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Data Penting");
        tbl.addColumn("ID Akomodasi");
        tbl.addColumn("ID Transportasi");
        tbl.addColumn("ID Perjalanan");
        
        jTable4.setModel(tbl); 
        jTable5.setModel(tbl);
           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `data_penting`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_data_penting"),
        rs.getString("id_akomodasi"),
        rs.getString("id_transportasi"),
        rs.getString("id_perjalanan"),
        
        });
    }

    jTable4.setModel(tbl);
    jTable5.setModel(tbl);

    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }
    
    public void datatable2(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Akomodasi");
        tbl.addColumn("Alamat Hotel");
        tbl.addColumn("Nama Hotel");
        tbl.addColumn("Tanggal Check-In");
        tbl.addColumn("Biaya Perorang");
        tbl.addColumn("Tanggal Check-Out");
        tbl.addColumn("Biaya Akomodasi");
        jTable1.setModel(tbl); 

           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `akomodasi`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_akomodasi"),
        rs.getString("alamat_hotel"),
        rs.getString("nama_hotel"),
        rs.getString("tanggal_check_in"),
        rs.getString("biaya_perorang"),
        rs.getString("tanggal_check_out"),
        rs.getString("biaya_akomodasi"),
        });
    }

    jTable1.setModel(tbl);

    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }

public void datatable3(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Transportasi");
        tbl.addColumn("Nomor Tiket");
        tbl.addColumn("Jenis Transportasi");
        tbl.addColumn("Biaya Perorang");
        tbl.addColumn("Tanggal Berangkat");
        tbl.addColumn("Total Transportasi");
        tbl.addColumn("Estimasi Waktu");
        jTable2.setModel(tbl); 

           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `transportasi`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_transportasi"),
        rs.getString("nomor_tiket"),
        rs.getString("jenis_transportasi"),
        rs.getString("biaya_perorang"),
        rs.getString("waktu_berangkat"),
        rs.getString("total_transportasi"),
        rs.getString("estimasi_waktu"),
        });
    }

    jTable2.setModel(tbl);

    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }

public void datatable4(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("Id Perjalanan");
        tbl.addColumn("Tanggal Mulai");
        tbl.addColumn("Tanggal Selesai");
        tbl.addColumn("Keperluan");
        tbl.addColumn("Tujuan");
        tbl.addColumn("Total Pegawai");
        tbl.addColumn("Rute Perjalanan");
        jTable3.setModel(tbl); 

           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `perjalanan`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_perjalanan"),
        rs.getString("tanggal_mulai"),
        rs.getString("tanggal_selesai"),
        rs.getString("keperluan"),
        rs.getString("tujuan"),
        rs.getString("total_pegawai"),
        rs.getString("rute_perjalanan"),
        
            
        });
    }

    jTable3.setModel(tbl);

    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }

    public void datatable5(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("Id RAB");
        tbl.addColumn("Estimasi Biaya Akomodasi");
        tbl.addColumn("Estimasi Biaya Transportasi");
        tbl.addColumn("Estimasi Biaya Harian");
        tbl.addColumn("Estimasi Biaya Perorang");
        tbl.addColumn("Total Rab");
        tbl.addColumn("Tanggal Pengajuan");
        tbl.addColumn("Status RAB");
        tbl.addColumn("Status Pemberian Dana");
        tbl.addColumn("Id Data Penting");
        jTable6.setModel(tbl);
        jTable7.setModel(tbl);

           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `rab`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_rab"),
        rs.getString("estimasi_biaya_akomodasi"),
        rs.getString("estimasi_biaya_transportasi"),
        rs.getString("estimasi_biaya_harian"),
        rs.getString("estimasi_biaya_perorang"),
        rs.getString("total_rab"),
        rs.getString("tanggal_pengajuan"),
        rs.getString("status_rab"),
        rs.getString("status_pemberian_dana"),
        rs.getString("id_data_Penting"),
        });
    }

    jTable6.setModel(tbl);
    jTable7.setModel(tbl);
    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }
    
    
    public void datatable6(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("Id LPJ");
        tbl.addColumn("Biaya Transportasi");
        tbl.addColumn("Biaya Akomodasi");
        tbl.addColumn("Biaya perorang");
        tbl.addColumn("Total LPJ");
        tbl.addColumn("Tanggal LPJ");
        tbl.addColumn("Bukti nota");
        tbl.addColumn("Status");
        jTable8.setModel(tbl);
       

           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `lpj`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_Lpj"),
        rs.getString("realisasi_biaya_transportasi"),
        rs.getString("realisasi_biaya_akomodasi"),
        rs.getString("realisasi_biaya_perorang"),
        rs.getString("total_realisasi_biaya"),
        rs.getString("tanggal_lpj"),
        rs.getString("bukti_nota"),
        rs.getString("status_lpj"),
            
        });
    }

   
    jTable8.setModel(tbl);

    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }
    
    public void datatable7(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Hasil Laporan");
        tbl.addColumn("ID RAB");
        tbl.addColumn("ID LPJ");
        
        jTable10.setModel(tbl); 
        jTable11.setModel(tbl); 
           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `hasil_laporan`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_hasil_laporan"),
        rs.getString("id_rab"),
        rs.getString("id_lpj"),
        
        });
    }

    jTable10.setModel(tbl);
    jTable11.setModel(tbl); 
    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }

    
     public void datatable8(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Sekertaris");
        tbl.addColumn("Nama");
        tbl.addColumn("Tanggal Lahir");
        tbl.addColumn("Nomor Telpon");
        tbl.addColumn("Email");
        tbl.addColumn("Gaji");
        tbl.addColumn("ID Surat Tugas");
        tbl.addColumn("ID Hasil Laporan");
        
        jTable12.setModel(tbl); 
           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `sekertaris`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_sekertaris"),
        rs.getString("nama"),
        rs.getString("tanggal_lahir"),
        rs.getString("nomor_telpon"),
        rs.getString("email"),
        rs.getString("gaji"),
        rs.getString("id_surat_tugas"),
        rs.getString("id_hasil_laporan"),
        });
    }

    jTable12.setModel(tbl);

    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }
    
     
     public void datatable9(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Surat");
        tbl.addColumn("Nomor Surat");
        tbl.addColumn("Tanggal Surat");
        tbl.addColumn("Deskripsi Tugas");
        tbl.addColumn("Penanggungjawab");
        tbl.addColumn("File Surat");
        tbl.addColumn("ID Pegawai");
        tbl.addColumn("ID Direktur");
        
        jTable9.setModel(tbl); 
           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `surat_tugas`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_surat_tugas"),
        rs.getString("nomor_surat"),
        rs.getString("tanggal_surat"),
        rs.getString("deskripsi_tugas"),
        rs.getString("penanggungjawab"),
        rs.getString("file_surat"),
        rs.getString("id_pegawai"),
        rs.getString("id_direktur"),
        });
    }

    jTable9.setModel(tbl);

    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }
      
    public void datapegawai(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Pegawai");
        tbl.addColumn("Nama");
        tbl.addColumn("Tanggal Lahir");
        tbl.addColumn("Nomor Telpon");
        tbl.addColumn("Alamat");
        tbl.addColumn("Email");
        tbl.addColumn("Jabatan");
        tbl.addColumn("Status Surat Tugas");
        tbl.addColumn("ID Hasil Laporan");
        
        jTable13.setModel(tbl);
        jTable20.setModel(tbl);
        
           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `pegawai`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_pegawai"),
        rs.getString("nama"),
        rs.getString("tanggal_lahir"),
        rs.getString("no_tlp"),
        rs.getString("alamat"),
        rs.getString("email"),
        rs.getString("jabatan"),
        rs.getString("status_surat_tugas"),
        rs.getString("id_hasil_laporan"),
        });
    }

    jTable13.setModel(tbl);
    jTable20.setModel(tbl);
    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }
    
    public void databendahara(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Bendahara");
        tbl.addColumn("Nama");
        tbl.addColumn("Email");
        tbl.addColumn("Nomor Telpon");
        tbl.addColumn("Tanggal Mulai Jabatan");
        tbl.addColumn("Saldo Keuangan");
        tbl.addColumn("Jumlah Transaksi");
        tbl.addColumn("ID Pegawai");
        
        jTable15.setModel(tbl); 
           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `bendahara`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("ID_Bendahara"),
        rs.getString("Nama_Bendahara"),
        rs.getString("Email_Bendahara"),
        rs.getString("Telepon_Bendahara"),
        rs.getString("Tanggal_Mulai_Jabatan"),
        rs.getString("Saldo_Keuangan"),
        rs.getString("Jumlah_Transaksi"),
        rs.getString("id_pegawai"),
        });
    }

    jTable15.setModel(tbl);

    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }
    
    public void databendahara1(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Bendahara");
        tbl.addColumn("Nama");
        tbl.addColumn("Email");
        tbl.addColumn("Nomor Telpon");
        tbl.addColumn("Tanggal Mulai Jabatan");
        tbl.addColumn("Saldo Keuangan");
        tbl.addColumn("Jumlah Transaksi");
        tbl.addColumn("ID Pegawai");
        
        jTable14.setModel(tbl); 
           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `bendahara`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("ID_Bendahara"),
        rs.getString("Nama_Bendahara"),
        rs.getString("Email_Bendahara"),
        rs.getString("Telepon_Bendahara"),
        rs.getString("Tanggal_Mulai_Jabatan"),
        rs.getString("Saldo_Keuangan"),
        rs.getString("Jumlah_Transaksi"),
        rs.getString("id_pegawai"),
        });
    }

    jTable14.setModel(tbl);

    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }

       public void dataseketaris(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Sekertaris");
        tbl.addColumn("Nama");
        tbl.addColumn("Tanggal Lahir");
        tbl.addColumn("Nomor Telpon");
        tbl.addColumn("Email");
        tbl.addColumn("Gaji");
        tbl.addColumn("ID Surat Tugas");
        tbl.addColumn("ID Hasil Laporan");
        
        jTable17.setModel(tbl); 
           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `sekertaris`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_sekertaris"),
        rs.getString("nama"),
        rs.getString("tanggal_lahir"),
        rs.getString("nomor_telpon"),
        rs.getString("email"),
        rs.getString("gaji"),
        rs.getString("id_surat_tugas"),
        rs.getString("id_hasil_laporan"),
        });
    }

    jTable17.setModel(tbl);

    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   } 
         public void datastaff(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Staff");
        tbl.addColumn("ID Bendahara");
        tbl.addColumn("ID Sekertaris");
        tbl.addColumn("ID Admin");
        tbl.addColumn("ID Pegawai");
        
        jTable16.setModel(tbl); 
           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `staff`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_staff"),
        rs.getString("id_bendahara"),
        rs.getString("id_sekertaris"),
        rs.getString("id_admin"),
        rs.getString("id_pegawai"),
        });
    }

    jTable16.setModel(tbl);

    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }
         
     public void datadirektur(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Direktur");
        tbl.addColumn("Nama");
        tbl.addColumn("Email");
        tbl.addColumn("Tanggal Lahir");
        tbl.addColumn("Alamat");
        tbl.addColumn("Gaji");
        tbl.addColumn("Nomor Telepon");
        tbl.addColumn("ID Staff");
        
        jTable19.setModel(tbl); 
           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `direktur`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_direktur"),
        rs.getString("nama_direktur"),
        rs.getString("email"),
        rs.getString("tanggal_lahir"),
        rs.getString("alamat"),
        rs.getString("gaji"),
        rs.getString("nomor_telpon"),
        rs.getString("id_staff"),
        });
    }

    jTable19.setModel(tbl);

    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }
              public void datastaff1(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Staff");
        tbl.addColumn("ID Bendahara");
        tbl.addColumn("ID Sekertaris");
        tbl.addColumn("ID Admin");
        tbl.addColumn("ID Pegawai");
        
        jTablestaff.setModel(tbl); 
           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `staff`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_staff"),
        rs.getString("id_bendahara"),
        rs.getString("id_sekertaris"),
        rs.getString("id_admin"),
        rs.getString("id_pegawai"),
        });
    }

    jTablestaff.setModel(tbl);

    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }
               public void datahasillaporan(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Hasil Laporan");
        tbl.addColumn("ID RAB");
        tbl.addColumn("ID LPJ");
        
        jTablestaff1.setModel(tbl); 
        
           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `hasil_laporan`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_hasil_laporan"),
        rs.getString("id_rab"),
        rs.getString("id_lpj"),
        
        });
    }

    jTablestaff1.setModel(tbl);
    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }
       
    public void datapegawai1(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Pegawai");
        tbl.addColumn("Nama");
        tbl.addColumn("Tanggal Lahir");
        tbl.addColumn("Nomor Telpon");
        tbl.addColumn("Alamat");
        tbl.addColumn("Email");
        tbl.addColumn("Jabatan");
        tbl.addColumn("Status Surat Tugas");
        tbl.addColumn("ID Hasil Laporan");
        jTable20.setModel(tbl); 
           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `pegawai`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_pegawai"),
        rs.getString("nama"),
        rs.getString("tanggal_lahir"),
        rs.getString("no_tlp"),
        rs.getString("alamat"),
        rs.getString("email"),
        rs.getString("jabatan"),
        rs.getString("status_surat_tugas"),
        rs.getString("id_hasil_laporan"),
        });
    }

    jTable20.setModel(tbl);

    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }
    
     public void datasurattugas(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Surat");
        tbl.addColumn("Nomor Surat");
        tbl.addColumn("Tanggal Surat");
        tbl.addColumn("Deskripsi Tugas");
        tbl.addColumn("Penanggungjawab");
        tbl.addColumn("File Surat");
        tbl.addColumn("ID Pegawai");
        tbl.addColumn("ID Direktur");
        
        jTable21.setModel(tbl); 
           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `surat_tugas`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_surat_tugas"),
        rs.getString("nomor_surat"),
        rs.getString("tanggal_surat"),
        rs.getString("deskripsi_tugas"),
        rs.getString("penanggungjawab"),
        rs.getString("file_surat"),
        rs.getString("id_pegawai"),
        rs.getString("id_direktur"),
        });
    }

    jTable21.setModel(tbl);

    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }
         
    public void datapegawai2(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Pegawai");
        tbl.addColumn("Nama");
        tbl.addColumn("Tanggal Lahir");
        tbl.addColumn("Nomor Telpon");
        tbl.addColumn("Alamat");
        tbl.addColumn("Email");
        tbl.addColumn("Jabatan");
        tbl.addColumn("Status Surat Tugas");
        tbl.addColumn("ID Hasil Laporan");
        jTablestaff2.setModel(tbl); 
           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `pegawai`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_pegawai"),
        rs.getString("nama"),
        rs.getString("tanggal_lahir"),
        rs.getString("no_tlp"),
        rs.getString("alamat"),
        rs.getString("email"),
        rs.getString("jabatan"),
        rs.getString("status_surat_tugas"),
        rs.getString("id_hasil_laporan"),
        });
    }

    jTablestaff2.setModel(tbl);

    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }

     
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        MainPanel = new javax.swing.JPanel();
        Edittable1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jButton46 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        jButton47 = new javax.swing.JButton();
        jButton48 = new javax.swing.JButton();
        jButton49 = new javax.swing.JButton();
        jButton50 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        Edittable2 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable5 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jTextField9 = new javax.swing.JTextField();
        jTextField10 = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jButton51 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTable6 = new javax.swing.JTable();
        jButton53 = new javax.swing.JButton();
        jButton54 = new javax.swing.JButton();
        jButton55 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        Edittable3 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTable7 = new javax.swing.JTable();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTable8 = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jTextField11 = new javax.swing.JTextField();
        jTextField12 = new javax.swing.JTextField();
        jTextField13 = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jButton52 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jScrollPane10 = new javax.swing.JScrollPane();
        jTable10 = new javax.swing.JTable();
        jButton56 = new javax.swing.JButton();
        jButton57 = new javax.swing.JButton();
        jButton58 = new javax.swing.JButton();
        jButton59 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        Edittable4 = new javax.swing.JPanel();
        jScrollPane9 = new javax.swing.JScrollPane();
        jTable9 = new javax.swing.JTable();
        jScrollPane11 = new javax.swing.JScrollPane();
        jTable11 = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jTextField14 = new javax.swing.JTextField();
        jTextField15 = new javax.swing.JTextField();
        jTextField16 = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jButton60 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jScrollPane12 = new javax.swing.JScrollPane();
        jTable12 = new javax.swing.JTable();
        jButton62 = new javax.swing.JButton();
        jButton63 = new javax.swing.JButton();
        jButton64 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        Edittable5 = new javax.swing.JPanel();
        jScrollPane13 = new javax.swing.JScrollPane();
        jTable13 = new javax.swing.JTable();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jTextField17 = new javax.swing.JTextField();
        jTextField19 = new javax.swing.JTextField();
        jLabel32 = new javax.swing.JLabel();
        jButton61 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jScrollPane15 = new javax.swing.JScrollPane();
        jTable15 = new javax.swing.JTable();
        jButton65 = new javax.swing.JButton();
        jButton66 = new javax.swing.JButton();
        jButton67 = new javax.swing.JButton();
        jButton16 = new javax.swing.JButton();
        jLabel33 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        Edittable6 = new javax.swing.JPanel();
        jScrollPane14 = new javax.swing.JScrollPane();
        jTable14 = new javax.swing.JTable();
        jLabel34 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jTextField18 = new javax.swing.JTextField();
        jTextField20 = new javax.swing.JTextField();
        jLabel38 = new javax.swing.JLabel();
        jButton68 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jScrollPane16 = new javax.swing.JScrollPane();
        jTable16 = new javax.swing.JTable();
        jButton69 = new javax.swing.JButton();
        jButton70 = new javax.swing.JButton();
        jButton71 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jScrollPane17 = new javax.swing.JScrollPane();
        jTable17 = new javax.swing.JTable();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jTextField21 = new javax.swing.JTextField();
        Edittable7 = new javax.swing.JPanel();
        jScrollPane18 = new javax.swing.JScrollPane();
        jTablestaff = new javax.swing.JTable();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jTextField22 = new javax.swing.JTextField();
        jLabel46 = new javax.swing.JLabel();
        jButton72 = new javax.swing.JButton();
        jButton19 = new javax.swing.JButton();
        jScrollPane19 = new javax.swing.JScrollPane();
        jTable19 = new javax.swing.JTable();
        jButton73 = new javax.swing.JButton();
        jButton74 = new javax.swing.JButton();
        jButton75 = new javax.swing.JButton();
        jButton20 = new javax.swing.JButton();
        jLabel47 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jTextField24 = new javax.swing.JTextField();
        Edittable8 = new javax.swing.JPanel();
        jScrollPane20 = new javax.swing.JScrollPane();
        jTablestaff1 = new javax.swing.JTable();
        jLabel49 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        jTextField23 = new javax.swing.JTextField();
        jLabel53 = new javax.swing.JLabel();
        jButton76 = new javax.swing.JButton();
        jButton21 = new javax.swing.JButton();
        jScrollPane21 = new javax.swing.JScrollPane();
        jTable20 = new javax.swing.JTable();
        jButton77 = new javax.swing.JButton();
        jButton78 = new javax.swing.JButton();
        jButton79 = new javax.swing.JButton();
        jButton22 = new javax.swing.JButton();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jTextField25 = new javax.swing.JTextField();
        Edittable9 = new javax.swing.JPanel();
        jScrollPane22 = new javax.swing.JScrollPane();
        jTablestaff2 = new javax.swing.JTable();
        jLabel57 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        jTextField26 = new javax.swing.JTextField();
        jLabel60 = new javax.swing.JLabel();
        jButton80 = new javax.swing.JButton();
        jScrollPane23 = new javax.swing.JScrollPane();
        jTable21 = new javax.swing.JTable();
        jButton81 = new javax.swing.JButton();
        jButton82 = new javax.swing.JButton();
        jButton83 = new javax.swing.JButton();
        jButton24 = new javax.swing.JButton();
        jLabel61 = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        jTextField27 = new javax.swing.JTextField();

        setLayout(new java.awt.CardLayout());

        MainPanel.setLayout(new java.awt.CardLayout());

        Edittable1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        Edittable1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 460, 191));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        Edittable1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 80, 481, 191));

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(jTable3);

        Edittable1.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 80, 481, 191));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("Edit Tabel Data Penting");
        Edittable1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 20, -1, -1));

        jLabel6.setText("ID Perjalanan");
        Edittable1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 446, 83, -1));

        jLabel7.setText("ID Akomodasi");
        Edittable1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 366, 83, -1));

        jLabel8.setText("ID Transportasi");
        Edittable1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 406, 83, -1));
        Edittable1.add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(135, 324, 140, -1));

        jTextField6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField6ActionPerformed(evt);
            }
        });
        Edittable1.add(jTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(135, 403, 140, -1));
        Edittable1.add(jTextField7, new org.netbeans.lib.awtextra.AbsoluteConstraints(135, 363, 140, -1));
        Edittable1.add(jTextField8, new org.netbeans.lib.awtextra.AbsoluteConstraints(135, 443, 140, -1));

        jLabel5.setText("ID Data Penting");
        Edittable1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 327, -1, -1));

        jButton46.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1search.png")); // NOI18N
        jButton46.setText("Cari");
        jButton46.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton46ActionPerformed(evt);
            }
        });
        Edittable1.add(jButton46, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 510, -1, -1));

        jButton8.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1arrow.png")); // NOI18N
        jButton8.setText("Hal. Selanjutnya");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        Edittable1.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1400, 340, -1, -1));

        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane4.setViewportView(jTable4);

        Edittable1.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(37, 595, 1009, 247));

        jButton47.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1save.png")); // NOI18N
        jButton47.setText("Simpan");
        jButton47.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton47ActionPerformed(evt);
            }
        });
        Edittable1.add(jButton47, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 510, -1, -1));

        jButton48.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1update.png")); // NOI18N
        jButton48.setText("Update");
        jButton48.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton48ActionPerformed(evt);
            }
        });
        Edittable1.add(jButton48, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 510, -1, -1));

        jButton49.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1reset.png")); // NOI18N
        jButton49.setText("Reset");
        jButton49.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton49ActionPerformed(evt);
            }
        });
        Edittable1.add(jButton49, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 510, -1, -1));

        jButton50.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1delete.png")); // NOI18N
        jButton50.setText("Hapus");
        jButton50.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton50ActionPerformed(evt);
            }
        });
        Edittable1.add(jButton50, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 510, -1, -1));

        jLabel9.setText("Tabel Akomodasi");
        Edittable1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, -1, 29));

        jLabel18.setText("Tabel Transportasi");
        Edittable1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 50, -1, 29));

        jLabel19.setText("Tabel Perjalanan");
        Edittable1.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 50, -1, 29));

        jLabel20.setText("Tabel Perjalanan");
        Edittable1.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(37, 560, -1, 29));

        MainPanel.add(Edittable1, "card2");

        jTable5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane5.setViewportView(jTable5);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Edit Tabel RAB");

        jLabel10.setText("ID Data Penting");

        jTextField10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField10ActionPerformed(evt);
            }
        });

        jLabel12.setText("ID RAB");

        jButton51.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1search.png")); // NOI18N
        jButton51.setText("Cari");
        jButton51.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton51ActionPerformed(evt);
            }
        });

        jButton9.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1arrow.png")); // NOI18N
        jButton9.setText("Hal. Selanjutnya");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jTable6.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane8.setViewportView(jTable6);

        jButton53.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1update.png")); // NOI18N
        jButton53.setText("Update");
        jButton53.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton53ActionPerformed(evt);
            }
        });

        jButton54.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1reset.png")); // NOI18N
        jButton54.setText("Reset");
        jButton54.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton54ActionPerformed(evt);
            }
        });

        jButton55.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1delete.png")); // NOI18N
        jButton55.setText("Hapus");
        jButton55.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton55ActionPerformed(evt);
            }
        });

        jButton10.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1arrowleft.png")); // NOI18N
        jButton10.setText("Hal. Selbelumnya");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jLabel21.setText("Tabel Data Penting");

        jLabel22.setText("Tabel RAB");

        javax.swing.GroupLayout Edittable2Layout = new javax.swing.GroupLayout(Edittable2);
        Edittable2.setLayout(Edittable2Layout);
        Edittable2Layout.setHorizontalGroup(
            Edittable2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Edittable2Layout.createSequentialGroup()
                .addGroup(Edittable2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Edittable2Layout.createSequentialGroup()
                        .addGap(615, 615, 615)
                        .addComponent(jLabel2))
                    .addGroup(Edittable2Layout.createSequentialGroup()
                        .addGap(1080, 1080, 1080)
                        .addComponent(jButton10)
                        .addGap(18, 18, 18)
                        .addComponent(jButton9))
                    .addGroup(Edittable2Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(Edittable2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(Edittable2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jScrollPane8, javax.swing.GroupLayout.DEFAULT_SIZE, 1009, Short.MAX_VALUE)
                                .addComponent(jScrollPane5)
                                .addGroup(Edittable2Layout.createSequentialGroup()
                                    .addGroup(Edittable2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGap(18, 18, 18)
                                    .addGroup(Edittable2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(Edittable2Layout.createSequentialGroup()
                                            .addComponent(jButton51)
                                            .addGap(18, 18, 18)
                                            .addComponent(jButton53)
                                            .addGap(18, 18, 18)
                                            .addComponent(jButton55)
                                            .addGap(18, 18, 18)
                                            .addComponent(jButton54))))
                                .addComponent(jLabel21)))))
                .addContainerGap(157, Short.MAX_VALUE))
        );
        Edittable2Layout.setVerticalGroup(
            Edittable2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Edittable2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(23, 23, 23)
                .addComponent(jLabel21)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(56, 56, 56)
                .addGroup(Edittable2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addGroup(Edittable2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addGap(99, 99, 99)
                .addGroup(Edittable2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton51)
                    .addComponent(jButton53)
                    .addComponent(jButton54)
                    .addComponent(jButton55))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 73, Short.MAX_VALUE)
                .addComponent(jLabel22)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(47, 47, 47)
                .addGroup(Edittable2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton9)
                    .addComponent(jButton10))
                .addGap(15, 15, 15))
        );

        MainPanel.add(Edittable2, "card2");

        jTable7.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane6.setViewportView(jTable7);

        jTable8.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane7.setViewportView(jTable8);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Edit Tabel Hasil Laporan");

        jLabel11.setText("ID RAB");

        jLabel13.setText("ID LPJ");

        jTextField12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField12ActionPerformed(evt);
            }
        });

        jLabel14.setText("ID Hasil Laporan");

        jButton52.setText("Cari");
        jButton52.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton52ActionPerformed(evt);
            }
        });

        jButton11.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1arrow.png")); // NOI18N
        jButton11.setText("Hal. Selanjutnya");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jTable10.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane10.setViewportView(jTable10);

        jButton56.setText("Simpan");
        jButton56.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton56ActionPerformed(evt);
            }
        });

        jButton57.setText("Update");
        jButton57.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton57ActionPerformed(evt);
            }
        });

        jButton58.setText("Reset");
        jButton58.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton58ActionPerformed(evt);
            }
        });

        jButton59.setText("Hapus");
        jButton59.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton59ActionPerformed(evt);
            }
        });

        jButton12.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1arrow.png")); // NOI18N
        jButton12.setText("Hal. Sebelumnya");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        jLabel23.setText("Tabel RAB");

        jLabel24.setText("Tabel LPJ");

        jLabel28.setText("Tabel Hasil Laporan");

        javax.swing.GroupLayout Edittable3Layout = new javax.swing.GroupLayout(Edittable3);
        Edittable3.setLayout(Edittable3Layout);
        Edittable3Layout.setHorizontalGroup(
            Edittable3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Edittable3Layout.createSequentialGroup()
                .addGroup(Edittable3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Edittable3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(Edittable3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Edittable3Layout.createSequentialGroup()
                                .addGap(609, 609, 609)
                                .addComponent(jLabel3))
                            .addGroup(Edittable3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(Edittable3Layout.createSequentialGroup()
                                    .addComponent(jButton12)
                                    .addGap(18, 18, 18)
                                    .addComponent(jButton11))
                                .addGroup(Edittable3Layout.createSequentialGroup()
                                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 397, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addGroup(Edittable3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 452, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGap(499, 499, 499)))))
                    .addGroup(Edittable3Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(Edittable3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, 93, Short.MAX_VALUE)
                            .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(Edittable3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(Edittable3Layout.createSequentialGroup()
                                .addComponent(jButton52)
                                .addGap(18, 18, 18)
                                .addComponent(jButton56)
                                .addGap(18, 18, 18)
                                .addComponent(jButton57)
                                .addGap(18, 18, 18)
                                .addComponent(jButton59)
                                .addGap(18, 18, 18)
                                .addComponent(jButton58)))))
                .addContainerGap(165, Short.MAX_VALUE))
            .addGroup(Edittable3Layout.createSequentialGroup()
                .addGroup(Edittable3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Edittable3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Edittable3Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addGroup(Edittable3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 1009, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel28))))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        Edittable3Layout.setVerticalGroup(
            Edittable3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Edittable3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addGap(36, 36, 36)
                .addGroup(Edittable3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(jLabel24))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Edittable3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 191, Short.MAX_VALUE)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(49, 49, 49)
                .addGroup(Edittable3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addGroup(Edittable3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addGap(18, 18, 18)
                .addGroup(Edittable3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13))
                .addGap(71, 71, 71)
                .addGroup(Edittable3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton52)
                    .addComponent(jButton56)
                    .addComponent(jButton57)
                    .addComponent(jButton58)
                    .addComponent(jButton59))
                .addGap(75, 75, 75)
                .addComponent(jLabel28)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addGroup(Edittable3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton11)
                    .addComponent(jButton12))
                .addGap(15, 15, 15))
        );

        MainPanel.add(Edittable3, "card2");

        jTable9.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane9.setViewportView(jTable9);

        jTable11.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane11.setViewportView(jTable11);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Edit Tabel Sekertaris");

        jLabel15.setText("ID Surat Tugas");

        jLabel16.setText("ID Hasil Laporan");

        jTextField15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField15ActionPerformed(evt);
            }
        });

        jLabel17.setText("ID Sekertaris");

        jButton60.setText("Cari");
        jButton60.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton60ActionPerformed(evt);
            }
        });

        jButton13.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1arrow.png")); // NOI18N
        jButton13.setText("Hal. Selanjutnya");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        jTable12.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane12.setViewportView(jTable12);

        jButton62.setText("Hapus");
        jButton62.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton62ActionPerformed(evt);
            }
        });

        jButton63.setText("Reset");
        jButton63.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton63ActionPerformed(evt);
            }
        });

        jButton64.setText("Update");
        jButton64.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton64ActionPerformed(evt);
            }
        });

        jButton14.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1arrow.png")); // NOI18N
        jButton14.setText("Hal. Sebelumnya");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        jLabel25.setText("Tabel Surat Tugas");

        jLabel26.setText("Tabel Hasil Laporan");

        jLabel27.setText("Tabel Sekertaris");

        javax.swing.GroupLayout Edittable4Layout = new javax.swing.GroupLayout(Edittable4);
        Edittable4.setLayout(Edittable4Layout);
        Edittable4Layout.setHorizontalGroup(
            Edittable4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Edittable4Layout.createSequentialGroup()
                .addGroup(Edittable4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Edittable4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(Edittable4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Edittable4Layout.createSequentialGroup()
                                .addGap(609, 609, 609)
                                .addComponent(jLabel4))
                            .addGroup(Edittable4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(Edittable4Layout.createSequentialGroup()
                                    .addComponent(jButton14)
                                    .addGap(18, 18, 18)
                                    .addComponent(jButton13))
                                .addGroup(Edittable4Layout.createSequentialGroup()
                                    .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 397, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addGroup(Edittable4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 452, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGap(499, 499, 499)))))
                    .addGroup(Edittable4Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(Edittable4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(Edittable4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField16, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField15, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(Edittable4Layout.createSequentialGroup()
                                .addGap(90, 90, 90)
                                .addComponent(jButton60)
                                .addGap(18, 18, 18)
                                .addComponent(jButton64)
                                .addGap(18, 18, 18)
                                .addComponent(jButton62)
                                .addGap(18, 18, 18)
                                .addComponent(jButton63)))))
                .addContainerGap(165, Short.MAX_VALUE))
            .addGroup(Edittable4Layout.createSequentialGroup()
                .addGroup(Edittable4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Edittable4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Edittable4Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addGroup(Edittable4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 1009, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        Edittable4Layout.setVerticalGroup(
            Edittable4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Edittable4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addGap(36, 36, 36)
                .addGroup(Edittable4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(jLabel26))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Edittable4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane11, javax.swing.GroupLayout.DEFAULT_SIZE, 191, Short.MAX_VALUE)
                    .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(49, 49, 49)
                .addGroup(Edittable4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addGroup(Edittable4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15))
                .addGap(18, 18, 18)
                .addGroup(Edittable4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16))
                .addGap(71, 71, 71)
                .addGroup(Edittable4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton60)
                    .addComponent(jButton63)
                    .addComponent(jButton64)
                    .addComponent(jButton62))
                .addGap(57, 57, 57)
                .addComponent(jLabel27)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 55, Short.MAX_VALUE)
                .addGroup(Edittable4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton13)
                    .addComponent(jButton14))
                .addGap(15, 15, 15))
        );

        MainPanel.add(Edittable4, "card2");

        jTable13.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane13.setViewportView(jTable13);

        jLabel29.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel29.setText("Edit Tabel Bendahara");

        jLabel31.setText("ID Pegawai");

        jTextField17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField17ActionPerformed(evt);
            }
        });

        jLabel32.setText("ID Bendahara");

        jButton61.setText("Cari");
        jButton61.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton61ActionPerformed(evt);
            }
        });

        jButton15.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1arrow.png")); // NOI18N
        jButton15.setText("Hal. Selanjutnya");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        jTable15.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane15.setViewportView(jTable15);

        jButton65.setText("Hapus");
        jButton65.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton65ActionPerformed(evt);
            }
        });

        jButton66.setText("Reset");
        jButton66.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton66ActionPerformed(evt);
            }
        });

        jButton67.setText("Update");
        jButton67.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton67ActionPerformed(evt);
            }
        });

        jButton16.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1arrow.png")); // NOI18N
        jButton16.setText("Hal. Sebelumnya");
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });

        jLabel33.setText("Tabel Pegawai");

        jLabel35.setText("Tabel Bendahara");

        javax.swing.GroupLayout Edittable5Layout = new javax.swing.GroupLayout(Edittable5);
        Edittable5.setLayout(Edittable5Layout);
        Edittable5Layout.setHorizontalGroup(
            Edittable5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Edittable5Layout.createSequentialGroup()
                .addGroup(Edittable5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Edittable5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Edittable5Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 1405, Short.MAX_VALUE))
            .addGroup(Edittable5Layout.createSequentialGroup()
                .addGroup(Edittable5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Edittable5Layout.createSequentialGroup()
                        .addGap(1075, 1075, 1075)
                        .addComponent(jButton16)
                        .addGap(18, 18, 18)
                        .addComponent(jButton15))
                    .addGroup(Edittable5Layout.createSequentialGroup()
                        .addGap(73, 73, 73)
                        .addComponent(jButton61)
                        .addGap(37, 37, 37)
                        .addComponent(jButton67)
                        .addGap(36, 36, 36)
                        .addComponent(jButton65)
                        .addGap(32, 32, 32)
                        .addComponent(jButton66))
                    .addGroup(Edittable5Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(Edittable5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane15, javax.swing.GroupLayout.PREFERRED_SIZE, 1009, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(Edittable5Layout.createSequentialGroup()
                                .addGroup(Edittable5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel31, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel32, javax.swing.GroupLayout.DEFAULT_SIZE, 83, Short.MAX_VALUE))
                                .addGap(49, 49, 49)
                                .addGroup(Edittable5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jTextField17, javax.swing.GroupLayout.DEFAULT_SIZE, 159, Short.MAX_VALUE)
                                    .addComponent(jTextField19))
                                .addGap(470, 470, 470)
                                .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(Edittable5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 923, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Edittable5Layout.createSequentialGroup()
                        .addGap(489, 489, 489)
                        .addComponent(jLabel29)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        Edittable5Layout.setVerticalGroup(
            Edittable5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Edittable5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel29)
                .addGap(36, 36, 36)
                .addComponent(jLabel33)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addGroup(Edittable5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel32)
                    .addComponent(jTextField17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel30)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Edittable5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Edittable5Layout.createSequentialGroup()
                        .addComponent(jLabel31)
                        .addGap(92, 92, 92)
                        .addGroup(Edittable5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton61)
                            .addComponent(jButton67)
                            .addComponent(jButton65)
                            .addComponent(jButton66)))
                    .addComponent(jTextField19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(70, 70, 70)
                .addComponent(jLabel35)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane15, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 72, Short.MAX_VALUE)
                .addGroup(Edittable5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton15)
                    .addComponent(jButton16))
                .addGap(15, 15, 15))
        );

        MainPanel.add(Edittable5, "card2");

        jTable14.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane14.setViewportView(jTable14);

        jLabel34.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel34.setText("Edit Tabel Staff");

        jLabel37.setText("ID Bendahara");

        jTextField18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField18ActionPerformed(evt);
            }
        });

        jLabel38.setText("ID Staff");

        jButton68.setText("Cari");
        jButton68.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton68ActionPerformed(evt);
            }
        });

        jButton17.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1arrow.png")); // NOI18N
        jButton17.setText("Hal. Selanjutnya");
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });

        jTable16.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane16.setViewportView(jTable16);

        jButton69.setText("Hapus");
        jButton69.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton69ActionPerformed(evt);
            }
        });

        jButton70.setText("Reset");
        jButton70.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton70ActionPerformed(evt);
            }
        });

        jButton71.setText("Update");
        jButton71.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton71ActionPerformed(evt);
            }
        });

        jButton18.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1arrow.png")); // NOI18N
        jButton18.setText("Hal. Sebelumnya");
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });

        jLabel39.setText("Tabel Bendahara");

        jLabel40.setText("Tabel Staff");

        jTable17.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane17.setViewportView(jTable17);

        jLabel41.setText("Tabel Sekretaris");

        jLabel42.setText("ID Sekretaris");

        jTextField21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField21ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Edittable6Layout = new javax.swing.GroupLayout(Edittable6);
        Edittable6.setLayout(Edittable6Layout);
        Edittable6Layout.setHorizontalGroup(
            Edittable6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Edittable6Layout.createSequentialGroup()
                .addGroup(Edittable6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Edittable6Layout.createSequentialGroup()
                        .addGap(1075, 1075, 1075)
                        .addComponent(jButton18)
                        .addGap(18, 18, 18)
                        .addComponent(jButton17))
                    .addGroup(Edittable6Layout.createSequentialGroup()
                        .addGap(73, 73, 73)
                        .addComponent(jButton68)
                        .addGap(37, 37, 37)
                        .addComponent(jButton71)
                        .addGap(36, 36, 36)
                        .addComponent(jButton69)
                        .addGap(32, 32, 32)
                        .addComponent(jButton70))
                    .addGroup(Edittable6Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(Edittable6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane16, javax.swing.GroupLayout.PREFERRED_SIZE, 1009, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(Edittable6Layout.createSequentialGroup()
                                .addGroup(Edittable6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(Edittable6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(jLabel37, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel38, javax.swing.GroupLayout.DEFAULT_SIZE, 83, Short.MAX_VALUE))
                                    .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(29, 29, 29)
                                .addGroup(Edittable6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextField20, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(Edittable6Layout.createSequentialGroup()
                                        .addGroup(Edittable6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jTextField18, javax.swing.GroupLayout.DEFAULT_SIZE, 159, Short.MAX_VALUE)
                                            .addComponent(jTextField21, javax.swing.GroupLayout.Alignment.TRAILING))
                                        .addGap(470, 470, 470)
                                        .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(Edittable6Layout.createSequentialGroup()
                        .addGap(489, 489, 489)
                        .addComponent(jLabel34))
                    .addGroup(Edittable6Layout.createSequentialGroup()
                        .addGroup(Edittable6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Edittable6Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, 376, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(Edittable6Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(Edittable6Layout.createSequentialGroup()
                                .addGap(37, 37, 37)
                                .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(88, 88, 88)
                        .addGroup(Edittable6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane17, javax.swing.GroupLayout.PREFERRED_SIZE, 376, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(165, Short.MAX_VALUE))
        );
        Edittable6Layout.setVerticalGroup(
            Edittable6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Edittable6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel34)
                .addGap(36, 36, 36)
                .addGroup(Edittable6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel39)
                    .addComponent(jLabel41))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Edittable6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane17, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(49, 49, 49)
                .addGroup(Edittable6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel38)
                    .addComponent(jTextField18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel36)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Edittable6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Edittable6Layout.createSequentialGroup()
                        .addComponent(jLabel37)
                        .addGap(12, 12, 12)
                        .addGroup(Edittable6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Edittable6Layout.createSequentialGroup()
                                .addComponent(jLabel42)
                                .addGap(64, 64, 64)
                                .addGroup(Edittable6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jButton68)
                                    .addComponent(jButton71)
                                    .addComponent(jButton69)
                                    .addComponent(jButton70))
                                .addGap(70, 70, 70)
                                .addComponent(jLabel40)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane16, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 72, Short.MAX_VALUE)
                                .addGroup(Edittable6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jButton17)
                                    .addComponent(jButton18))
                                .addGap(15, 15, 15))
                            .addGroup(Edittable6Layout.createSequentialGroup()
                                .addComponent(jTextField20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(Edittable6Layout.createSequentialGroup()
                        .addComponent(jTextField21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        MainPanel.add(Edittable6, "card2");

        jTablestaff.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane18.setViewportView(jTablestaff);

        jLabel43.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel43.setText("Edit Tabel Direktur");

        jLabel45.setText("ID Staff");

        jTextField22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField22ActionPerformed(evt);
            }
        });

        jLabel46.setText("ID Direktur");

        jButton72.setText("Cari");
        jButton72.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton72ActionPerformed(evt);
            }
        });

        jButton19.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1arrow.png")); // NOI18N
        jButton19.setText("Hal. Selanjutnya");
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });

        jTable19.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane19.setViewportView(jTable19);

        jButton73.setText("Hapus");
        jButton73.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton73ActionPerformed(evt);
            }
        });

        jButton74.setText("Reset");
        jButton74.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton74ActionPerformed(evt);
            }
        });

        jButton75.setText("Update");
        jButton75.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton75ActionPerformed(evt);
            }
        });

        jButton20.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1arrow.png")); // NOI18N
        jButton20.setText("Hal. Sebelumnya");
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });

        jLabel47.setText("Tabel Staff");

        jLabel48.setText("Tabel Direktur");

        jTextField24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField24ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Edittable7Layout = new javax.swing.GroupLayout(Edittable7);
        Edittable7.setLayout(Edittable7Layout);
        Edittable7Layout.setHorizontalGroup(
            Edittable7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Edittable7Layout.createSequentialGroup()
                .addGroup(Edittable7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Edittable7Layout.createSequentialGroup()
                        .addGap(1075, 1075, 1075)
                        .addComponent(jButton20)
                        .addGap(18, 18, 18)
                        .addComponent(jButton19))
                    .addGroup(Edittable7Layout.createSequentialGroup()
                        .addGap(73, 73, 73)
                        .addComponent(jButton72)
                        .addGap(37, 37, 37)
                        .addComponent(jButton75)
                        .addGap(36, 36, 36)
                        .addComponent(jButton73)
                        .addGap(32, 32, 32)
                        .addComponent(jButton74))
                    .addGroup(Edittable7Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(Edittable7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane19, javax.swing.GroupLayout.PREFERRED_SIZE, 1009, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(Edittable7Layout.createSequentialGroup()
                                .addGroup(Edittable7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(Edittable7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(jLabel45, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel46, javax.swing.GroupLayout.DEFAULT_SIZE, 83, Short.MAX_VALUE))
                                    .addComponent(jLabel50, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(29, 29, 29)
                                .addGroup(Edittable7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jTextField22, javax.swing.GroupLayout.DEFAULT_SIZE, 159, Short.MAX_VALUE)
                                    .addComponent(jTextField24, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addGap(470, 470, 470)
                                .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(Edittable7Layout.createSequentialGroup()
                        .addGroup(Edittable7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Edittable7Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jScrollPane18, javax.swing.GroupLayout.PREFERRED_SIZE, 376, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(Edittable7Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel47, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(Edittable7Layout.createSequentialGroup()
                                .addGap(37, 37, 37)
                                .addComponent(jLabel48, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(88, 88, 88)
                        .addComponent(jLabel43)))
                .addContainerGap(165, Short.MAX_VALUE))
        );
        Edittable7Layout.setVerticalGroup(
            Edittable7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Edittable7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel43)
                .addGap(36, 36, 36)
                .addComponent(jLabel47)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane18, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addGroup(Edittable7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel46)
                    .addComponent(jTextField22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel44)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Edittable7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Edittable7Layout.createSequentialGroup()
                        .addComponent(jLabel45)
                        .addGap(12, 12, 12)
                        .addComponent(jLabel50)
                        .addGap(64, 64, 64)
                        .addGroup(Edittable7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton72)
                            .addComponent(jButton75)
                            .addComponent(jButton73)
                            .addComponent(jButton74))
                        .addGap(70, 70, 70)
                        .addComponent(jLabel48)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane19, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 88, Short.MAX_VALUE)
                        .addGroup(Edittable7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton19)
                            .addComponent(jButton20))
                        .addGap(15, 15, 15))
                    .addGroup(Edittable7Layout.createSequentialGroup()
                        .addComponent(jTextField24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        MainPanel.add(Edittable7, "card2");

        jTablestaff1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane20.setViewportView(jTablestaff1);

        jLabel49.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel49.setText("Edit Tabel Pegawai");

        jLabel52.setText("ID Staff");

        jTextField23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField23ActionPerformed(evt);
            }
        });

        jLabel53.setText("ID Pegawai");

        jButton76.setText("Cari");
        jButton76.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton76ActionPerformed(evt);
            }
        });

        jButton21.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1arrow.png")); // NOI18N
        jButton21.setText("Hal. Selanjutnya");
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });

        jTable20.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane21.setViewportView(jTable20);

        jButton77.setText("Hapus");
        jButton77.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton77ActionPerformed(evt);
            }
        });

        jButton78.setText("Reset");
        jButton78.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton78ActionPerformed(evt);
            }
        });

        jButton79.setText("Update");
        jButton79.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton79ActionPerformed(evt);
            }
        });

        jButton22.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1arrow.png")); // NOI18N
        jButton22.setText("Hal. Sebelumnya");
        jButton22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton22ActionPerformed(evt);
            }
        });

        jLabel54.setText("Tabel Staff");

        jLabel55.setText("Tabel Pegawai");

        jTextField25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField25ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Edittable8Layout = new javax.swing.GroupLayout(Edittable8);
        Edittable8.setLayout(Edittable8Layout);
        Edittable8Layout.setHorizontalGroup(
            Edittable8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Edittable8Layout.createSequentialGroup()
                .addGroup(Edittable8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Edittable8Layout.createSequentialGroup()
                        .addGap(1075, 1075, 1075)
                        .addComponent(jButton22)
                        .addGap(18, 18, 18)
                        .addComponent(jButton21))
                    .addGroup(Edittable8Layout.createSequentialGroup()
                        .addGap(73, 73, 73)
                        .addComponent(jButton76)
                        .addGap(37, 37, 37)
                        .addComponent(jButton79)
                        .addGap(36, 36, 36)
                        .addComponent(jButton77)
                        .addGap(32, 32, 32)
                        .addComponent(jButton78))
                    .addGroup(Edittable8Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(Edittable8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane21, javax.swing.GroupLayout.PREFERRED_SIZE, 1009, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(Edittable8Layout.createSequentialGroup()
                                .addGroup(Edittable8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(Edittable8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(jLabel52, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel53, javax.swing.GroupLayout.DEFAULT_SIZE, 83, Short.MAX_VALUE))
                                    .addComponent(jLabel56, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(29, 29, 29)
                                .addGroup(Edittable8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jTextField23, javax.swing.GroupLayout.DEFAULT_SIZE, 159, Short.MAX_VALUE)
                                    .addComponent(jTextField25, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addGap(470, 470, 470)
                                .addComponent(jLabel51, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(Edittable8Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane20, javax.swing.GroupLayout.PREFERRED_SIZE, 376, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Edittable8Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel54, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Edittable8Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(jLabel55, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Edittable8Layout.createSequentialGroup()
                        .addGap(462, 462, 462)
                        .addComponent(jLabel49)))
                .addContainerGap(165, Short.MAX_VALUE))
        );
        Edittable8Layout.setVerticalGroup(
            Edittable8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Edittable8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel49)
                .addGap(36, 36, 36)
                .addComponent(jLabel54)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane20, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addGroup(Edittable8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel53)
                    .addComponent(jTextField23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel51)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Edittable8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Edittable8Layout.createSequentialGroup()
                        .addComponent(jLabel52)
                        .addGap(12, 12, 12)
                        .addComponent(jLabel56)
                        .addGap(64, 64, 64)
                        .addGroup(Edittable8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton76)
                            .addComponent(jButton79)
                            .addComponent(jButton77)
                            .addComponent(jButton78))
                        .addGap(70, 70, 70)
                        .addComponent(jLabel55)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane21, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 88, Short.MAX_VALUE)
                        .addGroup(Edittable8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton21)
                            .addComponent(jButton22))
                        .addGap(15, 15, 15))
                    .addGroup(Edittable8Layout.createSequentialGroup()
                        .addComponent(jTextField25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        MainPanel.add(Edittable8, "card2");

        jTablestaff2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane22.setViewportView(jTablestaff2);

        jLabel57.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel57.setText("Edit Tabel Surat Tugas Pegawai");

        jLabel59.setText("ID Pegawai");

        jTextField26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField26ActionPerformed(evt);
            }
        });

        jLabel60.setText("ID Surat Tugas");

        jButton80.setText("Cari");
        jButton80.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton80ActionPerformed(evt);
            }
        });

        jTable21.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane23.setViewportView(jTable21);

        jButton81.setText("Hapus");
        jButton81.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton81ActionPerformed(evt);
            }
        });

        jButton82.setText("Reset");
        jButton82.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton82ActionPerformed(evt);
            }
        });

        jButton83.setText("Update");
        jButton83.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton83ActionPerformed(evt);
            }
        });

        jButton24.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1arrow.png")); // NOI18N
        jButton24.setText("Hal. Sebelumnya");
        jButton24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton24ActionPerformed(evt);
            }
        });

        jLabel61.setText("Tabel Pegawai");

        jLabel62.setText("Tabel Surat Tugas");

        jTextField27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField27ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Edittable9Layout = new javax.swing.GroupLayout(Edittable9);
        Edittable9.setLayout(Edittable9Layout);
        Edittable9Layout.setHorizontalGroup(
            Edittable9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Edittable9Layout.createSequentialGroup()
                .addGroup(Edittable9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Edittable9Layout.createSequentialGroup()
                        .addGap(1075, 1075, 1075)
                        .addComponent(jButton24))
                    .addGroup(Edittable9Layout.createSequentialGroup()
                        .addGap(73, 73, 73)
                        .addComponent(jButton80)
                        .addGap(37, 37, 37)
                        .addComponent(jButton83)
                        .addGap(36, 36, 36)
                        .addComponent(jButton81)
                        .addGap(32, 32, 32)
                        .addComponent(jButton82))
                    .addGroup(Edittable9Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(Edittable9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane23, javax.swing.GroupLayout.PREFERRED_SIZE, 1009, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(Edittable9Layout.createSequentialGroup()
                                .addGroup(Edittable9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(Edittable9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(jLabel59, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel60, javax.swing.GroupLayout.DEFAULT_SIZE, 83, Short.MAX_VALUE))
                                    .addComponent(jLabel63, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(29, 29, 29)
                                .addGroup(Edittable9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jTextField26, javax.swing.GroupLayout.DEFAULT_SIZE, 159, Short.MAX_VALUE)
                                    .addComponent(jTextField27, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addGap(470, 470, 470)
                                .addComponent(jLabel58, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(Edittable9Layout.createSequentialGroup()
                        .addGroup(Edittable9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Edittable9Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jScrollPane22, javax.swing.GroupLayout.PREFERRED_SIZE, 376, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(Edittable9Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel61, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(Edittable9Layout.createSequentialGroup()
                                .addGap(37, 37, 37)
                                .addComponent(jLabel62, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(67, 67, 67)
                        .addComponent(jLabel57)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        Edittable9Layout.setVerticalGroup(
            Edittable9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Edittable9Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel57)
                .addGap(18, 18, 18)
                .addComponent(jLabel61)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane22, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addGroup(Edittable9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel60)
                    .addComponent(jTextField26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel58)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Edittable9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Edittable9Layout.createSequentialGroup()
                        .addComponent(jLabel59)
                        .addGap(12, 12, 12)
                        .addComponent(jLabel63)
                        .addGap(64, 64, 64)
                        .addGroup(Edittable9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton80)
                            .addComponent(jButton83)
                            .addComponent(jButton81)
                            .addComponent(jButton82))
                        .addGap(70, 70, 70)
                        .addComponent(jLabel62)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane23, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 79, Short.MAX_VALUE)
                        .addComponent(jButton24)
                        .addGap(15, 15, 15))
                    .addGroup(Edittable9Layout.createSequentialGroup()
                        .addComponent(jTextField27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        MainPanel.add(Edittable9, "card2");

        add(MainPanel, "card2");
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField6ActionPerformed

    private void jButton46ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton46ActionPerformed
     try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL untuk SELECT
    String query = "SELECT * FROM `data_penting` WHERE id_data_penting = ?";
    java.sql.PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dengan ID LPJ dari input
    preparedStatement.setString(1, jTextField5.getText().trim()); // id_Lpj

    // Menjalankan query
    ResultSet rs = preparedStatement.executeQuery();

    // Membuat model untuk JTable
    DefaultTableModel tbl = new DefaultTableModel();
    tbl.addColumn("ID Data Penting");
    tbl.addColumn("ID Akomodasi");
    tbl.addColumn("ID Transportasi");
    tbl.addColumn("ID Perjalanan");

    // Variabel untuk melacak apakah data ditemukan
    boolean dataFound = false;

    // Memasukkan data hasil query ke model tabel dan JTextField
    if (rs.next()) {
        dataFound = true;
        do {
            tbl.addRow(new Object[]{
                rs.getString("id_data_penting"),
                rs.getString("id_akomodasi"),
                rs.getString("id_transportasi"),
                rs.getString("id_perjalanan"),
            });

            // Hanya ambil data untuk JTextField dari baris pertama
            if (tbl.getRowCount() == 1) {
                jTextField5.setText(rs.getString("id_data_penting"));
                jTextField6.setText(rs.getString("id_akomodasi"));
                jTextField7.setText(rs.getString("id_transportasi"));
                jTextField8.setText(rs.getString("id_perjalanan"));
            }
        } while (rs.next());
    }

    // Menampilkan data pada JTable
    jTable4.setModel(tbl);

    // Menampilkan pesan jika data tidak ditemukan
    if (!dataFound) {
        JOptionPane.showMessageDialog(null, "Data dengan ID LPJ tersebut tidak ditemukan.");
    } else {
        JOptionPane.showMessageDialog(null, "Data ditemukan!");
    }

    // Menutup resources
    rs.close();
    preparedStatement.close();
    conn.close();
} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
    }//GEN-LAST:event_jButton46ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
    MainPanel.removeAll();
    MainPanel.repaint();
    MainPanel.revalidate();
    
    MainPanel.add(Edittable2);
    MainPanel.repaint();
    MainPanel.revalidate();
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton47ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton47ActionPerformed
    try {
    // Membuat koneksi ke database
    java.sql.Connection conn = (Connection) konektor.koneksiDB();
    
    // SQL query dengan placeholder untuk parameter
    String sql = "INSERT INTO `data_penting`(`id_data_penting`, `id_akomodasi`, `id_transportasi`, `id_perjalanan`) "
            + "VALUES (?, ?, ?, ?)";
    
    // Menggunakan PreparedStatement untuk mencegah SQL Injection
    java.sql.PreparedStatement pst = conn.prepareStatement(sql);
    
    // Mengatur parameter untuk PreparedStatement
    pst.setString(1, jTextField5.getText());  
    pst.setString(2, jTextField6.getText());  
    pst.setString(3, jTextField7.getText());  
    pst.setString(4, jTextField8.getText());  
      
    
    // Menjalankan perintah SQL
    pst.execute();
    
    // Memanggil method untuk memperbarui tampilan tabel atau lainnya
    datatable1();
    
    // Menampilkan pesan sukses
    JOptionPane.showMessageDialog(null, "Penyimpanan Data Berhasil");
} catch (Exception e) {
    // Menampilkan pesan error jika ada kesalahan
    JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
}
    }//GEN-LAST:event_jButton47ActionPerformed

    private void jButton48ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton48ActionPerformed
        try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL untuk UPDATE
    String query = "UPDATE `data_penting` SET id_akomodasi = ?, id_transportasi = ?, id_perjalanan = ? WHERE id_data_penting = ?";
    java.sql.PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dengan data dari input
    preparedStatement.setString(1, jTextField6.getText().trim()); // id_akomodasi
    preparedStatement.setString(2, jTextField7.getText().trim()); // id_trasportasi
    preparedStatement.setString(3, jTextField8.getText().trim()); // id_perjalanan
    preparedStatement.setString(4, jTextField5.getText().trim()); // id_data_penting (primary key)

    // Menjalankan query UPDATE
    int rowsUpdated = preparedStatement.executeUpdate();

    // Menampilkan pesan berdasarkan hasil UPDATE
    if (rowsUpdated > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil diperbarui!");
    } else {
        JOptionPane.showMessageDialog(null, "Data dengan ID tersebut tidak ditemukan.");
    }
    datatable1();
    // Menutup resources
    preparedStatement.close();
    conn.close();
} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
    }//GEN-LAST:event_jButton48ActionPerformed

    private void jButton49ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton49ActionPerformed
    jTextField5.setText(" ");
    jTextField6.setText(" ");
    jTextField7.setText(" ");
    jTextField8.setText(" ");
     datatable1();
     datatable2();
     datatable3();
     datatable4();
    }//GEN-LAST:event_jButton49ActionPerformed

    private void jButton50ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton50ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL untuk DELETE
    String query = "DELETE FROM `data_penting` WHERE id_data_penting = ?";
    java.sql.PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dengan ID dari input
    preparedStatement.setString(1, jTextField5.getText().trim()); // id_data_penting (primary key)

    // Menjalankan query DELETE
    int rowsDeleted = preparedStatement.executeUpdate();

    // Menampilkan pesan berdasarkan hasil DELETE
    if (rowsDeleted > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
    } else {
        JOptionPane.showMessageDialog(null, "Data dengan ID tersebut tidak ditemukan.");
    }
    datatable1();
    // Menutup resources
    preparedStatement.close();
    conn.close();
} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
    }//GEN-LAST:event_jButton50ActionPerformed

    private void jTextField10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField10ActionPerformed

    private void jButton51ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton51ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement
    String query = "SELECT *" +
                   "FROM rab " +
                   "WHERE id_rab = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);
    preparedStatement.setString(1, jTextField9.getText()); // Mengisi parameter query

    // Menjalankan query
    ResultSet rs = preparedStatement.executeQuery();

    // Membuat model tabel dan menambahkan kolom
    DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("Id RAB");
        tbl.addColumn("Estimasi Biaya Akomodasi");
        tbl.addColumn("Estimasi Biaya Transportasi");
        tbl.addColumn("Estimasi Biaya Harian");
        tbl.addColumn("Estimasi Biaya Perorang");
        tbl.addColumn("Total Rab");
        tbl.addColumn("Tanggal Pengajuan");
        tbl.addColumn("Status");
        tbl.addColumn("ID Data Penting");
        jTable6.setModel(tbl); 

    // Mengisi tabel dengan data hasil query
    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_rab"),
        rs.getString("estimasi_biaya_akomodasi"),
        rs.getString("estimasi_biaya_transportasi"),
        rs.getString("estimasi_biaya_harian"),
        rs.getString("estimasi_biaya_perorang"),
        rs.getString("total_rab"),
        rs.getString("tanggal_pengajuan"),
        rs.getString("status_rab"),
        rs.getString("status_pemberian_dana"),
        rs.getString("id_data_penting"),
            
        });
    }

    jTable6.setModel(tbl);

    // Menutup koneksi dan statement
    rs.close();
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}
    }//GEN-LAST:event_jButton51ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        MainPanel.removeAll();
        MainPanel.repaint();
        MainPanel.revalidate();

        MainPanel.add(Edittable3);
        MainPanel.repaint();
        MainPanel.revalidate();
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton53ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton53ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL untuk UPDATE
    String query = "UPDATE rab SET id_data_penting = ? WHERE id_rab = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dengan nilai dari input
    preparedStatement.setString(1, jTextField10.getText().trim()); // id_data_penting (baru)
    preparedStatement.setString(2, jTextField9.getText().trim()); // id_rab (identifikasi)

    // Menjalankan query UPDATE
    int rowsUpdated = preparedStatement.executeUpdate();

    // Menampilkan pesan berdasarkan hasil UPDATE
    if (rowsUpdated > 0) {
        JOptionPane.showMessageDialog(null, "id_data_penting berhasil diperbarui!");
    } else {
        JOptionPane.showMessageDialog(null, "Data dengan id_rab tersebut tidak ditemukan.");
    }

    // Menutup koneksi dan statement
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}

    }//GEN-LAST:event_jButton53ActionPerformed

    private void jButton54ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton54ActionPerformed
    jTextField10.setText("");
    jTextField9.setText("");
    datatable5();
    }//GEN-LAST:event_jButton54ActionPerformed

    private void jButton55ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton55ActionPerformed
           try {
            // Membuat koneksi
            Connection conn = konektor.koneksiDB();

            // Membuat query SQL untuk DELETE
            String query = "DELETE FROM rab WHERE id_rab = ?";
            PreparedStatement preparedStatement = conn.prepareStatement(query);

            // Mengisi parameter query dengan nilai dari input
            preparedStatement.setString(1, jTextField9.getText().trim()); // id_rab

            // Menjalankan query DELETE
            int rowsDeleted = preparedStatement.executeUpdate();

            // Menampilkan pesan berdasarkan hasil DELETE
            if (rowsDeleted > 0) {
                JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
            } else {
                JOptionPane.showMessageDialog(null, "Data dengan id_rab tersebut tidak ditemukan.");
            }

            // Menutup koneksi dan statement
            preparedStatement.close();
            conn.close();

        } catch (Exception e) {
            // Menangani error
            JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
        }
    }//GEN-LAST:event_jButton55ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
    MainPanel.removeAll();
        MainPanel.repaint();
        MainPanel.revalidate();

        MainPanel.add(Edittable1);
        MainPanel.repaint();
        MainPanel.revalidate();
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jTextField12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField12ActionPerformed

    private void jButton52ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton52ActionPerformed
       try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement
    String query = "SELECT *" +
                   "FROM hasil_laporan " +
                   "WHERE id_hasil_laporan = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);
    preparedStatement.setString(1, jTextField11.getText()); // Mengisi parameter query

    // Menjalankan query
    ResultSet rs = preparedStatement.executeQuery();

    // Membuat model tabel dan menambahkan kolom
    DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Hasil Laporan");
        tbl.addColumn("ID RAB");
        tbl.addColumn("ID LPJ");
        
        jTable10.setModel(tbl); 

    // Mengisi tabel dengan data hasil query
    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_hasil_laporan"),
        rs.getString("id_rab"),
        rs.getString("id_lpj"),
        
            
        });
    }

    jTable10.setModel(tbl);

    // Menutup koneksi dan statement
    rs.close();
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}
    }//GEN-LAST:event_jButton52ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
    MainPanel.removeAll();
        MainPanel.repaint();
        MainPanel.revalidate();

        MainPanel.add(Edittable4);
        MainPanel.repaint();
        MainPanel.revalidate();
        
    
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton56ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton56ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement untuk INSERT
    String query = "INSERT INTO hasil_laporan (id_hasil_laporan, id_rab, id_lpj) VALUES (?, ?, ?)";
    PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dari input user
    preparedStatement.setString(1, jTextField11.getText()); // ID Hasil Laporan
    preparedStatement.setString(2, jTextField12.getText()); // ID RAB
    preparedStatement.setString(3, jTextField13.getText()); // ID LPJ

    // Menjalankan query INSERT
    int rowsInserted = preparedStatement.executeUpdate();

    // Menampilkan pesan berhasil atau gagal
    if (rowsInserted > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil ditambahkan.");
    } else {
        JOptionPane.showMessageDialog(null, "Data gagal ditambahkan.");
    }

    // Menutup koneksi dan statement
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}

    }//GEN-LAST:event_jButton56ActionPerformed

    private void jButton57ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton57ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement untuk UPDATE
    String query = "UPDATE hasil_laporan SET id_rab = ?, id_lpj = ? WHERE id_hasil_laporan = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dari input user
    preparedStatement.setString(1, jTextField12.getText()); // ID RAB
    preparedStatement.setString(2, jTextField13.getText()); // ID LPJ
    preparedStatement.setString(3, jTextField11.getText()); // ID Hasil Laporan (kunci untuk WHERE)

    // Menjalankan query UPDATE
    int rowsUpdated = preparedStatement.executeUpdate();

    // Menampilkan pesan berhasil atau gagal
    if (rowsUpdated > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil diperbarui.");
    } else {
        JOptionPane.showMessageDialog(null, "Data gagal diperbarui atau tidak ditemukan.");
    }

    // Menutup koneksi dan statement
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}

    }//GEN-LAST:event_jButton57ActionPerformed

    private void jButton58ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton58ActionPerformed
    jTextField11.setText("");
    jTextField12.setText("");
    jTextField13.setText("");
    datatable7();
    }//GEN-LAST:event_jButton58ActionPerformed

    private void jButton59ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton59ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement untuk DELETE
    String query = "DELETE FROM hasil_laporan WHERE id_hasil_laporan = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dari input user
    preparedStatement.setString(1, jTextField11.getText()); // ID Hasil Laporan (kunci untuk WHERE)

    // Menjalankan query DELETE
    int rowsDeleted = preparedStatement.executeUpdate();

    // Menampilkan pesan berhasil atau gagal
    if (rowsDeleted > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil dihapus.");
    } else {
        JOptionPane.showMessageDialog(null, "Data tidak ditemukan atau gagal dihapus.");
    }

    // Menutup koneksi dan statement
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}

    }//GEN-LAST:event_jButton59ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
    MainPanel.removeAll();
        MainPanel.repaint();
        MainPanel.revalidate();

        MainPanel.add(Edittable2);
        MainPanel.repaint();
        MainPanel.revalidate();
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jTextField15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField15ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField15ActionPerformed

    private void jButton60ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton60ActionPerformed
    try {
    // Validasi input
    if (jTextField14.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(null, "Kolom id_sekertaris tidak boleh kosong!");
        return;
    }

    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement
    String query = "SELECT * " +
                   "FROM sekertaris " + 
                   "WHERE id_sekertaris = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);
    preparedStatement.setString(1, jTextField14.getText()); // Mengisi parameter query

    // Menjalankan query
    ResultSet rs = preparedStatement.executeQuery();

    // Membuat model tabel dan menambahkan kolom
    DefaultTableModel tbl = new DefaultTableModel();
    tbl.addColumn("ID Sekertaris");
    tbl.addColumn("Nama");
    tbl.addColumn("Tanggal Lahir");
    tbl.addColumn("Nomor Telpon");
    tbl.addColumn("Email");
    tbl.addColumn("Gaji");
    tbl.addColumn("ID Surat Tugas");
    tbl.addColumn("ID Hasil Laporan");
    jTable12.setModel(tbl);

    // Mengisi tabel dengan data hasil query
    while (rs.next()) {
        tbl.addRow(new Object[]{
            rs.getString("id_sekertaris"),
            rs.getString("nama"),
            rs.getString("tanggal_lahir"),
            rs.getString("nomor_telpon"),
            rs.getString("email"),
            rs.getString("gaji"),
            rs.getString("id_surat_tugas"),
            rs.getString("id_hasil_laporan"),
        });
    }

    jTable12.setModel(tbl);

    // Menutup koneksi dan statement
    rs.close();
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}


    }//GEN-LAST:event_jButton60ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
    MainPanel.removeAll();
        MainPanel.repaint();
        MainPanel.revalidate();

        MainPanel.add(Edittable5);
        MainPanel.repaint();
        MainPanel.revalidate();
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton62ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton62ActionPerformed
     try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement untuk DELETE
    String query = "DELETE FROM sekertaris WHERE id_sekertaris = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dari input user
    preparedStatement.setString(1, jTextField14.getText()); 

    // Menjalankan query DELETE
    int rowsDeleted = preparedStatement.executeUpdate();

    // Menampilkan pesan berhasil atau gagal
    if (rowsDeleted > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil dihapus.");
    } else {
        JOptionPane.showMessageDialog(null, "Data tidak ditemukan atau gagal dihapus.");
    }

    // Menutup koneksi dan statement
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}
    }//GEN-LAST:event_jButton62ActionPerformed

    private void jButton63ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton63ActionPerformed
    jTextField14.setText("");
    jTextField15.setText("");
    jTextField16.setText("");
    
    }//GEN-LAST:event_jButton63ActionPerformed

    private void jButton64ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton64ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement untuk UPDATE
    String query = "UPDATE sekertaris SET id_surat_tugas = ?, id_hasil_laporan = ? WHERE id_sekertaris = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dari input user
    preparedStatement.setString(1, jTextField15.getText()); 
    preparedStatement.setString(2, jTextField16.getText()); 
    preparedStatement.setString(3, jTextField14.getText()); 

    // Menjalankan query UPDATE
    int rowsUpdated = preparedStatement.executeUpdate();

    // Menampilkan pesan berhasil atau gagal
    if (rowsUpdated > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil diperbarui.");
    } else {
        JOptionPane.showMessageDialog(null, "Data gagal diperbarui atau tidak ditemukan.");
    }

    // Menutup koneksi dan statement
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}
    }//GEN-LAST:event_jButton64ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
    MainPanel.removeAll();
        MainPanel.repaint();
        MainPanel.revalidate();

        MainPanel.add(Edittable3);
        MainPanel.repaint();
        MainPanel.revalidate();
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
    MainPanel.removeAll();
        MainPanel.repaint();
        MainPanel.revalidate();

        MainPanel.add(Edittable4);
        MainPanel.repaint();
        MainPanel.revalidate();
    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton67ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton67ActionPerformed
     try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement untuk UPDATE
    String query = "UPDATE bendahara SET id_pegawai = ? WHERE ID_Bendahara = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dari input user
    preparedStatement.setString(1, jTextField17.getText()); 
    preparedStatement.setString(2, jTextField19.getText()); 

    // Menjalankan query UPDATE
    int rowsUpdated = preparedStatement.executeUpdate();

    // Menampilkan pesan berhasil atau gagal
    if (rowsUpdated > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil diperbarui.");
    } else {
        JOptionPane.showMessageDialog(null, "Data gagal diperbarui atau tidak ditemukan.");
    }

    // Menutup koneksi dan statement
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}
    }//GEN-LAST:event_jButton67ActionPerformed

    private void jButton66ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton66ActionPerformed
    jTextField17.setText("");
    jTextField19.setText("");
    }//GEN-LAST:event_jButton66ActionPerformed

    private void jButton65ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton65ActionPerformed
     try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement untuk DELETE
    String query = "DELETE FROM bendahara WHERE ID_Bendahara = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dari input user
    preparedStatement.setString(1, jTextField17.getText()); 

    // Menjalankan query DELETE
    int rowsDeleted = preparedStatement.executeUpdate();

    // Menampilkan pesan berhasil atau gagal
    if (rowsDeleted > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil dihapus.");
    } else {
        JOptionPane.showMessageDialog(null, "Data tidak ditemukan atau gagal dihapus.");
    }

    // Menutup koneksi dan statement
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}

    }//GEN-LAST:event_jButton65ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
    MainPanel.removeAll();
        MainPanel.repaint();
        MainPanel.revalidate();

        MainPanel.add(Edittable6);
        MainPanel.repaint();
        MainPanel.revalidate();
    }//GEN-LAST:event_jButton15ActionPerformed

    private void jButton61ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton61ActionPerformed
try {
    // Validasi input
    if (jTextField17.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(null, "Kolom ID_Bendahara tidak boleh kosong!");
        return;
    }

    // Membuat koneksi dan statement menggunakan try-with-resources
    String query = "SELECT * FROM bendahara WHERE ID_Bendahara = ?";
    try (Connection conn = konektor.koneksiDB();
         PreparedStatement preparedStatement = conn.prepareStatement(query)) {
         
        // Mengisi parameter query
        preparedStatement.setString(1, jTextField17.getText());

        // Menjalankan query
        try (ResultSet rs = preparedStatement.executeQuery()) {
            // Membuat model tabel
            DefaultTableModel tbl = new DefaultTableModel();
            tbl.addColumn("ID Bendahara");
            tbl.addColumn("Nama");
            tbl.addColumn("Email");
            tbl.addColumn("Nomor Telpon");
            tbl.addColumn("Tanggal Mulai Jabatan");
            tbl.addColumn("Saldo Keuangan");
            tbl.addColumn("Jumlah Transaksi");
            tbl.addColumn("ID Pegawai");

            // Mengisi tabel dengan data hasil query
            boolean dataFound = false;
            while (rs.next()) {
                tbl.addRow(new Object[]{
                    rs.getString("ID_Bendahara"),
                    rs.getString("Nama_Bendahara"),
                    rs.getString("Email_Bendahara"),
                    rs.getString("Telepon_Bendahara"),
                    rs.getString("Tanggal_Mulai_Jabatan"),
                    rs.getString("Saldo_Keuangan"),
                    rs.getString("Jumlah_Transaksi"),
                    rs.getString("id_pegawai")
                });
                dataFound = true;
            }

            // Set model ke tabel
            jTable15.setModel(tbl);

            // Menampilkan pesan jika data tidak ditemukan
            if (!dataFound) {
                JOptionPane.showMessageDialog(null, "Data tidak ditemukan!");
            }
        }
    }
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}
    }//GEN-LAST:event_jButton61ActionPerformed

    private void jTextField17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField17ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField17ActionPerformed

    private void jTextField18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField18ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField18ActionPerformed

    private void jButton68ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton68ActionPerformed
     try {
    // Validasi input
    if (jTextField18.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(null, "Kolom id_staff tidak boleh kosong!");
        return;
    }

    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement
    String query = "SELECT * " +
                   "FROM staff " + 
                   "WHERE id_staff = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);
    preparedStatement.setString(1, jTextField18.getText()); // Mengisi parameter query

    // Menjalankan query
    ResultSet rs = preparedStatement.executeQuery();

    // Membuat model tabel dan menambahkan kolom
    DefaultTableModel tbl = new DefaultTableModel();
    tbl.addColumn("ID Staff");
    tbl.addColumn("ID Bendahara");
    tbl.addColumn("ID Sekertaris");
    tbl.addColumn("ID Admin");
    tbl.addColumn("ID Pegawai");
    jTable16.setModel(tbl);

    // Mengisi tabel dengan data hasil query
    while (rs.next()) {
        tbl.addRow(new Object[]{
            rs.getString("id_staff"),
            rs.getString("id_bendahara"),
            rs.getString("id_sekertaris"),
            rs.getString("id_admin"),
            rs.getString("id_pegawai"),
      
        });
    }

    jTable16.setModel(tbl);

    // Menutup koneksi dan statement
    rs.close();
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}


    }//GEN-LAST:event_jButton68ActionPerformed

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
    MainPanel.removeAll();
        MainPanel.repaint();
        MainPanel.revalidate();

        MainPanel.add(Edittable7);
        MainPanel.repaint();
        MainPanel.revalidate();
    }//GEN-LAST:event_jButton17ActionPerformed

    private void jButton69ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton69ActionPerformed
     try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement untuk DELETE
    String query = "DELETE FROM staff WHERE id_staff = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dari input user
    preparedStatement.setString(1, jTextField18.getText()); 

    // Menjalankan query DELETE
    int rowsDeleted = preparedStatement.executeUpdate();

    // Menampilkan pesan berhasil atau gagal
    if (rowsDeleted > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil dihapus.");
    } else {
        JOptionPane.showMessageDialog(null, "Data tidak ditemukan atau gagal dihapus.");
    }

    // Menutup koneksi dan statement
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}


    }//GEN-LAST:event_jButton69ActionPerformed

    private void jButton70ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton70ActionPerformed
    jTextField18.setText("");
    jTextField21.setText("");
    jTextField20.setText("");
    
    }//GEN-LAST:event_jButton70ActionPerformed

    private void jButton71ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton71ActionPerformed
   try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement untuk UPDATE
    String query = "UPDATE staff SET id_sekertaris = ?, id_bendahara = ? WHERE id_staff = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dari input user
    preparedStatement.setString(1, jTextField18.getText()); 
    preparedStatement.setString(2, jTextField21.getText()); 
    preparedStatement.setString(3, jTextField20.getText()); 

    // Menjalankan query UPDATE
    int rowsUpdated = preparedStatement.executeUpdate();

    // Menampilkan pesan berhasil atau gagal
    if (rowsUpdated > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil diperbarui.");
    } else {
        JOptionPane.showMessageDialog(null, "Data gagal diperbarui atau tidak ditemukan.");
    }

    // Menutup koneksi dan statement
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}
    }//GEN-LAST:event_jButton71ActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
     MainPanel.removeAll();
        MainPanel.repaint();
        MainPanel.revalidate();

        MainPanel.add(Edittable5);
        MainPanel.repaint();
        MainPanel.revalidate();

    }//GEN-LAST:event_jButton18ActionPerformed

    private void jTextField21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField21ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField21ActionPerformed

    private void jTextField22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField22ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField22ActionPerformed

    private void jButton72ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton72ActionPerformed
   try {
    // Validasi input
    if (jTextField22.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(null, "Kolom id_direktur tidak boleh kosong!");
        return;
    }

    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement
    String query = "SELECT * " +
                   "FROM direktur " + 
                   "WHERE id_direktur = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);
    preparedStatement.setString(1, jTextField22.getText()); // Mengisi parameter query

    // Menjalankan query
    ResultSet rs = preparedStatement.executeQuery();

    // Membuat model tabel dan menambahkan kolom
    DefaultTableModel tbl = new DefaultTableModel();
    tbl.addColumn("ID Direktur");
    tbl.addColumn("Nama");
    tbl.addColumn("Email");
    tbl.addColumn("Tanggal Lahir");
    tbl.addColumn("Alamat");
    tbl.addColumn("Gaji");
    tbl.addColumn("Nomor Telepon");
    tbl.addColumn("ID Staff");
    jTable19.setModel(tbl);

    // Mengisi tabel dengan data hasil query
    while (rs.next()) {
        tbl.addRow(new Object[]{
            rs.getString("id_direktur"),
            rs.getString("nama_direktur"),
            rs.getString("email"),
            rs.getString("tanggal_lahir"),
            rs.getString("alamat"),
            rs.getString("gaji"),
            rs.getString("nomor_telpon"),
            rs.getString("id_staff"),
        });
    }

    jTable19.setModel(tbl);

    // Menutup koneksi dan statement
    rs.close();
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}
    }//GEN-LAST:event_jButton72ActionPerformed

    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed
    MainPanel.removeAll();
        MainPanel.repaint();
        MainPanel.revalidate();

        MainPanel.add(Edittable8);
        MainPanel.repaint();
        MainPanel.revalidate();
    }//GEN-LAST:event_jButton19ActionPerformed

    private void jButton73ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton73ActionPerformed
     try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement untuk DELETE
    String query = "DELETE FROM direktur WHERE id_direktur = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dari input user
    preparedStatement.setString(1, jTextField22.getText()); 

    // Menjalankan query DELETE
    int rowsDeleted = preparedStatement.executeUpdate();

    // Menampilkan pesan berhasil atau gagal
    if (rowsDeleted > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil dihapus.");
    } else {
        JOptionPane.showMessageDialog(null, "Data tidak ditemukan atau gagal dihapus.");
    }

    // Menutup koneksi dan statement
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}
    }//GEN-LAST:event_jButton73ActionPerformed

    private void jButton74ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton74ActionPerformed
    jTextField22.setText("");
    jTextField24.setText("");
    }//GEN-LAST:event_jButton74ActionPerformed

    private void jButton75ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton75ActionPerformed
     try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement untuk UPDATE
    String query = "UPDATE direktur SET id_staff = ? WHERE id_direktur = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dari input user
    preparedStatement.setString(1, jTextField22.getText()); 
    preparedStatement.setString(2, jTextField24.getText()); 

    // Menjalankan query UPDATE
    int rowsUpdated = preparedStatement.executeUpdate();

    // Menampilkan pesan berhasil atau gagal
    if (rowsUpdated > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil diperbarui.");
    } else {
        JOptionPane.showMessageDialog(null, "Data gagal diperbarui atau tidak ditemukan.");
    }

    // Menutup koneksi dan statement
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}
    }//GEN-LAST:event_jButton75ActionPerformed

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
     MainPanel.removeAll();
        MainPanel.repaint();
        MainPanel.revalidate();

        MainPanel.add(Edittable6);
        MainPanel.repaint();
        MainPanel.revalidate();
    }//GEN-LAST:event_jButton20ActionPerformed

    private void jTextField24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField24ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField24ActionPerformed

    private void jTextField23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField23ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField23ActionPerformed

    private void jButton76ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton76ActionPerformed
   try {
    // Validasi input
    if (jTextField23.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(null, "Kolom id_pegawai tidak boleh kosong!");
        return;
    }

    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement
    String query = "SELECT * " +
                   "FROM pegawai " + 
                   "WHERE id_pegawai = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);
    preparedStatement.setString(1, jTextField23.getText()); // Mengisi parameter query

    // Menjalankan query
    ResultSet rs = preparedStatement.executeQuery();

    // Membuat model tabel dan menambahkan kolom
     DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Pegawai");
        tbl.addColumn("Nama");
        tbl.addColumn("Tanggal Lahir");
        tbl.addColumn("Nomor Telpon");
        tbl.addColumn("Alamat");
        tbl.addColumn("Email");
        tbl.addColumn("Jabatan");
        tbl.addColumn("Status Surat Tugas");
        tbl.addColumn("ID Hasil Laporan");
    jTable20.setModel(tbl);

    // Mengisi tabel dengan data hasil query
    while (rs.next()) {
        tbl.addRow(new Object[]{
           rs.getString("id_pegawai"),
        rs.getString("nama"),
        rs.getString("tanggal_lahir"),
        rs.getString("no_tlp"),
        rs.getString("alamat"),
        rs.getString("email"),
        rs.getString("jabatan"),
        rs.getString("status_surat_tugas"),
        rs.getString("id_hasil_laporan"),
        });
    }

    jTable20.setModel(tbl);

    // Menutup koneksi dan statement
    rs.close();
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}
    }//GEN-LAST:event_jButton76ActionPerformed

    private void jButton77ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton77ActionPerformed
     try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement untuk DELETE
    String query = "DELETE FROM pegawai WHERE id_pegawai = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dari input user
    preparedStatement.setString(1, jTextField23.getText()); 

    // Menjalankan query DELETE
    int rowsDeleted = preparedStatement.executeUpdate();

    // Menampilkan pesan berhasil atau gagal
    if (rowsDeleted > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil dihapus.");
    } else {
        JOptionPane.showMessageDialog(null, "Data tidak ditemukan atau gagal dihapus.");
    }

    // Menutup koneksi dan statement
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}
    }//GEN-LAST:event_jButton77ActionPerformed

    private void jButton78ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton78ActionPerformed
    jTextField23.setText("");
    jTextField25.setText("");
    }//GEN-LAST:event_jButton78ActionPerformed

    private void jButton79ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton79ActionPerformed
     try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement untuk UPDATE
    String query = "UPDATE pegawai SET id_staff = ? WHERE id_pegawai = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dari input user
    preparedStatement.setString(1, jTextField23.getText()); 
    preparedStatement.setString(2, jTextField25.getText()); 

    // Menjalankan query UPDATE
    int rowsUpdated = preparedStatement.executeUpdate();

    // Menampilkan pesan berhasil atau gagal
    if (rowsUpdated > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil diperbarui.");
    } else {
        JOptionPane.showMessageDialog(null, "Data gagal diperbarui atau tidak ditemukan.");
    }

    // Menutup koneksi dan statement
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}
    }//GEN-LAST:event_jButton79ActionPerformed

    private void jButton22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton22ActionPerformed
     MainPanel.removeAll();
        MainPanel.repaint();
        MainPanel.revalidate();

        MainPanel.add(Edittable7);
        MainPanel.repaint();
        MainPanel.revalidate();
    }//GEN-LAST:event_jButton22ActionPerformed

    private void jTextField25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField25ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField25ActionPerformed

    private void jTextField26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField26ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField26ActionPerformed

    private void jButton80ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton80ActionPerformed
   try {
    // Validasi input
    if (jTextField26.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(null, "Kolom id_surat_tugas tidak boleh kosong!");
        return;
    }

    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement
    String query = "SELECT * " +
                   "FROM surat_tugas " + 
                   "WHERE id_surat_tugas = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);
    preparedStatement.setString(1, jTextField26.getText()); // Mengisi parameter query

    // Menjalankan query
    ResultSet rs = preparedStatement.executeQuery();

    // Membuat model tabel dan menambahkan kolom
    DefaultTableModel tbl = new DefaultTableModel();
    tbl.addColumn("ID Surat Tugas");
    tbl.addColumn("Nomor Surat");
    tbl.addColumn("Tanggal Surat");
    tbl.addColumn("Deskripsi");
    tbl.addColumn("PJ");
    tbl.addColumn("File Surat");
    tbl.addColumn("ID Pegawai");
    tbl.addColumn("ID Direktur");
    jTable21.setModel(tbl);

    // Mengisi tabel dengan data hasil query
    while (rs.next()) {
        tbl.addRow(new Object[]{
            rs.getString("id_surat_tugas"),
            rs.getString("nomor_surat"),
            rs.getString("tanggal_surat"),
            rs.getString("deskripsi_tugas"),
            rs.getString("penanggungjawab"),
            rs.getString("file_surat"),
            rs.getString("id_pegawai"),
            rs.getString("id_direktur"),
        });
    }

    jTable21.setModel(tbl);

    // Menutup koneksi dan statement
    rs.close();
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}
    }//GEN-LAST:event_jButton80ActionPerformed

    private void jButton81ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton81ActionPerformed
     try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement untuk DELETE
    String query = "DELETE FROM surat_tugas WHERE id_surat_tugas = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dari input user
    preparedStatement.setString(1, jTextField26.getText()); 

    // Menjalankan query DELETE
    int rowsDeleted = preparedStatement.executeUpdate();

    // Menampilkan pesan berhasil atau gagal
    if (rowsDeleted > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil dihapus.");
    } else {
        JOptionPane.showMessageDialog(null, "Data tidak ditemukan atau gagal dihapus.");
    }

    // Menutup koneksi dan statement
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}
    }//GEN-LAST:event_jButton81ActionPerformed

    private void jButton82ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton82ActionPerformed
    jTextField26.setText("");
    jTextField27.setText("");
    }//GEN-LAST:event_jButton82ActionPerformed

    private void jButton83ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton83ActionPerformed
     try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement untuk UPDATE
    String query = "UPDATE surat_tugas SET id_pegawai = ? WHERE id_surat_tugas = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dari input user
    preparedStatement.setString(1, jTextField26.getText()); 
    preparedStatement.setString(2, jTextField27.getText()); 

    // Menjalankan query UPDATE
    int rowsUpdated = preparedStatement.executeUpdate();

    // Menampilkan pesan berhasil atau gagal
    if (rowsUpdated > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil diperbarui.");
    } else {
        JOptionPane.showMessageDialog(null, "Data gagal diperbarui atau tidak ditemukan.");
    }

    // Menutup koneksi dan statement
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}    }//GEN-LAST:event_jButton83ActionPerformed

    private void jButton24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton24ActionPerformed
     MainPanel.removeAll();
        MainPanel.repaint();
        MainPanel.revalidate();

        MainPanel.add(Edittable8);
        MainPanel.repaint();
        MainPanel.revalidate();
    }//GEN-LAST:event_jButton24ActionPerformed

    private void jTextField27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField27ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField27ActionPerformed

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
    MainPanel.removeAll();
        MainPanel.repaint();
        MainPanel.revalidate();

        MainPanel.add(Edittable9);
        MainPanel.repaint();
        MainPanel.revalidate();
    }//GEN-LAST:event_jButton21ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Edittable1;
    private javax.swing.JPanel Edittable2;
    private javax.swing.JPanel Edittable3;
    private javax.swing.JPanel Edittable4;
    private javax.swing.JPanel Edittable5;
    private javax.swing.JPanel Edittable6;
    private javax.swing.JPanel Edittable7;
    private javax.swing.JPanel Edittable8;
    private javax.swing.JPanel Edittable9;
    private javax.swing.JPanel MainPanel;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton46;
    private javax.swing.JButton jButton47;
    private javax.swing.JButton jButton48;
    private javax.swing.JButton jButton49;
    private javax.swing.JButton jButton50;
    private javax.swing.JButton jButton51;
    private javax.swing.JButton jButton52;
    private javax.swing.JButton jButton53;
    private javax.swing.JButton jButton54;
    private javax.swing.JButton jButton55;
    private javax.swing.JButton jButton56;
    private javax.swing.JButton jButton57;
    private javax.swing.JButton jButton58;
    private javax.swing.JButton jButton59;
    private javax.swing.JButton jButton60;
    private javax.swing.JButton jButton61;
    private javax.swing.JButton jButton62;
    private javax.swing.JButton jButton63;
    private javax.swing.JButton jButton64;
    private javax.swing.JButton jButton65;
    private javax.swing.JButton jButton66;
    private javax.swing.JButton jButton67;
    private javax.swing.JButton jButton68;
    private javax.swing.JButton jButton69;
    private javax.swing.JButton jButton70;
    private javax.swing.JButton jButton71;
    private javax.swing.JButton jButton72;
    private javax.swing.JButton jButton73;
    private javax.swing.JButton jButton74;
    private javax.swing.JButton jButton75;
    private javax.swing.JButton jButton76;
    private javax.swing.JButton jButton77;
    private javax.swing.JButton jButton78;
    private javax.swing.JButton jButton79;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton80;
    private javax.swing.JButton jButton81;
    private javax.swing.JButton jButton82;
    private javax.swing.JButton jButton83;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane16;
    private javax.swing.JScrollPane jScrollPane17;
    private javax.swing.JScrollPane jScrollPane18;
    private javax.swing.JScrollPane jScrollPane19;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane20;
    private javax.swing.JScrollPane jScrollPane21;
    private javax.swing.JScrollPane jScrollPane22;
    private javax.swing.JScrollPane jScrollPane23;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable10;
    private javax.swing.JTable jTable11;
    private javax.swing.JTable jTable12;
    private javax.swing.JTable jTable13;
    private javax.swing.JTable jTable14;
    private javax.swing.JTable jTable15;
    private javax.swing.JTable jTable16;
    private javax.swing.JTable jTable17;
    private javax.swing.JTable jTable19;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable20;
    private javax.swing.JTable jTable21;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable4;
    private javax.swing.JTable jTable5;
    private javax.swing.JTable jTable6;
    private javax.swing.JTable jTable7;
    private javax.swing.JTable jTable8;
    private javax.swing.JTable jTable9;
    private javax.swing.JTable jTablestaff;
    private javax.swing.JTable jTablestaff1;
    private javax.swing.JTable jTablestaff2;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField16;
    private javax.swing.JTextField jTextField17;
    private javax.swing.JTextField jTextField18;
    private javax.swing.JTextField jTextField19;
    private javax.swing.JTextField jTextField20;
    private javax.swing.JTextField jTextField21;
    private javax.swing.JTextField jTextField22;
    private javax.swing.JTextField jTextField23;
    private javax.swing.JTextField jTextField24;
    private javax.swing.JTextField jTextField25;
    private javax.swing.JTextField jTextField26;
    private javax.swing.JTextField jTextField27;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration//GEN-END:variables
}
