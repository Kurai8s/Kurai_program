package File_Project;


import Koneksi.konektor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */

/**
 *
 * @author Asus
 */
public class RABPegawai extends javax.swing.JPanel {

    /**
     * Creates new form RABPegawai
     */
    public RABPegawai() {
        initComponents();
        datatable1();
        datatable2();
        datatable3();
        datatable4();
    }

    
    public void datatable1(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("Id RAB");
        tbl.addColumn("Estimasi Biaya Akomodasi");
        tbl.addColumn("Estimasi Biaya Transportasi");
        tbl.addColumn("Estimasi Biaya Harian");
        tbl.addColumn("Estimasi Biaya Perorang");
        tbl.addColumn("Total Rab");
        tbl.addColumn("Tanggal Pengajuan");
        tbl.addColumn("Status RAB");
        tbl.addColumn("Status Pemberian Dana");
        jTable5.setModel(tbl);
         jTable1.setModel(tbl);

           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `rab`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_rab"),
        rs.getString("estimasi_biaya_akomodasi"),
        rs.getString("estimasi_biaya_transportasi"),
        rs.getString("estimasi_biaya_harian"),
        rs.getString("estimasi_biaya_perorang"),
        rs.getString("total_rab"),
        rs.getString("tanggal_pengajuan"),
        rs.getString("status_rab"),
        rs.getString("status_pemberian_dana"),
            
        });
    }

    jTable5.setModel(tbl);
     jTable1.setModel(tbl);
    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }
    
public void datatable2(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Akomodasi");
        tbl.addColumn("Alamat Hotel");
        tbl.addColumn("Nama Hotel");
        tbl.addColumn("Tanggal Check-In");
        tbl.addColumn("Biaya Perorang");
        tbl.addColumn("Tanggal Check-Out");
        tbl.addColumn("Biaya Akomodasi");
        jTable3.setModel(tbl); 

           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `akomodasi`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_akomodasi"),
        rs.getString("alamat_hotel"),
        rs.getString("nama_hotel"),
        rs.getString("tanggal_check_in"),
        rs.getString("biaya_perorang"),
        rs.getString("tanggal_check_out"),
        rs.getString("biaya_akomodasi"),
        });
    }

    jTable3.setModel(tbl);

    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }

public void datatable3(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Transportasi");
        tbl.addColumn("Nomor Tiket");
        tbl.addColumn("Jenis Transportasi");
        tbl.addColumn("Biaya Perorang");
        tbl.addColumn("Tanggal Berangkat");
        tbl.addColumn("Total Transportasi");
        tbl.addColumn("Estimasi Waktu");
        jTable2.setModel(tbl); 

           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `transportasi`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_transportasi"),
        rs.getString("nomor_tiket"),
        rs.getString("jenis_transportasi"),
        rs.getString("biaya_perorang"),
        rs.getString("waktu_berangkat"),
        rs.getString("total_transportasi"),
        rs.getString("estimasi_waktu"),
        });
    }

    jTable2.setModel(tbl);

    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }

public void datatable4(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("Id Perjalanan");
        tbl.addColumn("Tanggal Mulai");
        tbl.addColumn("Tanggal Selesai");
        tbl.addColumn("Keperluan");
        tbl.addColumn("Tujuan");
        tbl.addColumn("Total Pegawai");
        tbl.addColumn("Rute Perjalanan");
        jTable4.setModel(tbl); 

           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `perjalanan`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_perjalanan"),
        rs.getString("tanggal_mulai"),
        rs.getString("tanggal_selesai"),
        rs.getString("keperluan"),
        rs.getString("tujuan"),
        rs.getString("total_pegawai"),
        rs.getString("rute_perjalanan"),
        
            
        });
    }

    jTable4.setModel(tbl);

    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }

    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        mainPanel = new javax.swing.JPanel();
        Buat_RAB = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        edittransportasi = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jButton6 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton26 = new javax.swing.JButton();
        jButton27 = new javax.swing.JButton();
        editakomodasi = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jTextField10 = new javax.swing.JTextField();
        jButton10 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jTextField11 = new javax.swing.JTextField();
        jTextField12 = new javax.swing.JTextField();
        jTextField13 = new javax.swing.JTextField();
        jTextField14 = new javax.swing.JTextField();
        jTextField15 = new javax.swing.JTextField();
        jTextField16 = new javax.swing.JTextField();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton24 = new javax.swing.JButton();
        jButton25 = new javax.swing.JButton();
        editperjalanan = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jTextField18 = new javax.swing.JTextField();
        jButton14 = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jTextField19 = new javax.swing.JTextField();
        jTextField20 = new javax.swing.JTextField();
        jTextField21 = new javax.swing.JTextField();
        jTextField22 = new javax.swing.JTextField();
        jTextField23 = new javax.swing.JTextField();
        jTextField24 = new javax.swing.JTextField();
        jButton15 = new javax.swing.JButton();
        jButton16 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jButton28 = new javax.swing.JButton();
        jButton29 = new javax.swing.JButton();
        editrab = new javax.swing.JPanel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jTextField25 = new javax.swing.JTextField();
        jButton18 = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable5 = new javax.swing.JTable();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jTextField26 = new javax.swing.JTextField();
        jTextField27 = new javax.swing.JTextField();
        jTextField28 = new javax.swing.JTextField();
        jTextField29 = new javax.swing.JTextField();
        jTextField30 = new javax.swing.JTextField();
        jTextField31 = new javax.swing.JTextField();
        jButton19 = new javax.swing.JButton();
        jButton20 = new javax.swing.JButton();
        jButton21 = new javax.swing.JButton();
        jLabel37 = new javax.swing.JLabel();
        jButton22 = new javax.swing.JButton();
        jButton23 = new javax.swing.JButton();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setLayout(new java.awt.CardLayout());

        mainPanel.setLayout(new java.awt.CardLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("MEMBUAT RAB");

        jLabel2.setText("ID_RAB");

        jButton1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1search.png")); // NOI18N
        jButton1.setText("Cari");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1edit.png")); // NOI18N
        jButton2.setText("Edit RAB");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1edit.png")); // NOI18N
        jButton3.setText("Edit Akomodasi");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1edit.png")); // NOI18N
        jButton4.setText("Edit Trasportasi");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1edit.png")); // NOI18N
        jButton5.setText("Edit  Perjalanan");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout Buat_RABLayout = new javax.swing.GroupLayout(Buat_RAB);
        Buat_RAB.setLayout(Buat_RABLayout);
        Buat_RABLayout.setHorizontalGroup(
            Buat_RABLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Buat_RABLayout.createSequentialGroup()
                .addGroup(Buat_RABLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Buat_RABLayout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Buat_RABLayout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addGroup(Buat_RABLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 652, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(Buat_RABLayout.createSequentialGroup()
                                .addComponent(jButton1)
                                .addGroup(Buat_RABLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(Buat_RABLayout.createSequentialGroup()
                                        .addGap(184, 184, 184)
                                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(Buat_RABLayout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton2)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton3)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton4)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton5)))))))
                .addContainerGap(30, Short.MAX_VALUE))
        );
        Buat_RABLayout.setVerticalGroup(
            Buat_RABLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Buat_RABLayout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addGroup(Buat_RABLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50)
                .addGroup(Buat_RABLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3)
                    .addComponent(jButton4)
                    .addComponent(jButton5))
                .addGap(31, 31, 31)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(352, Short.MAX_VALUE))
        );

        mainPanel.add(Buat_RAB, "card2");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("MEMBUAT RAB TRANSPORTASI");

        jLabel4.setText("ID Transportasi");

        jButton6.setText("Cari");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jTable2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7", "Title 8"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        jLabel5.setText("Nomor Tiket");

        jLabel6.setText("Jenis Transportasi");

        jLabel7.setText("Biaya Transportasi");

        jLabel8.setText("Biaya Perorang");

        jLabel9.setText("Waktu Berangkat");

        jLabel10.setText("Total Transportasi");

        jLabel11.setText("Estimasi Waktu");

        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });

        jTextField6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField6ActionPerformed(evt);
            }
        });

        jTextField8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField8ActionPerformed(evt);
            }
        });

        jButton7.setText("Simpan");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setText("Hapus");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton9.setText("Reset");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jButton26.setText("Update");
        jButton26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton26ActionPerformed(evt);
            }
        });

        jButton27.setText("Keluar");
        jButton27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton27ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout edittransportasiLayout = new javax.swing.GroupLayout(edittransportasi);
        edittransportasi.setLayout(edittransportasiLayout);
        edittransportasiLayout.setHorizontalGroup(
            edittransportasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(edittransportasiLayout.createSequentialGroup()
                .addGroup(edittransportasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(edittransportasiLayout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addGroup(edittransportasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton7)
                            .addGroup(edittransportasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(edittransportasiLayout.createSequentialGroup()
                                    .addComponent(jLabel11)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(edittransportasiLayout.createSequentialGroup()
                                    .addComponent(jLabel10)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(edittransportasiLayout.createSequentialGroup()
                                    .addComponent(jLabel9)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(edittransportasiLayout.createSequentialGroup()
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(edittransportasiLayout.createSequentialGroup()
                                    .addGroup(edittransportasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel5)
                                        .addComponent(jLabel6)
                                        .addComponent(jLabel7))
                                    .addGroup(edittransportasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(edittransportasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(edittransportasiLayout.createSequentialGroup()
                                                .addGap(54, 54, 54)
                                                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, edittransportasiLayout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(edittransportasiLayout.createSequentialGroup()
                                            .addGap(54, 54, 54)
                                            .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, edittransportasiLayout.createSequentialGroup()
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                        .addGap(18, 18, 18)
                        .addGroup(edittransportasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(edittransportasiLayout.createSequentialGroup()
                                .addComponent(jButton26)
                                .addGap(18, 18, 18)
                                .addComponent(jButton8))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, edittransportasiLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jButton6))))
                    .addGroup(edittransportasiLayout.createSequentialGroup()
                        .addGap(263, 263, 263)
                        .addComponent(jLabel3)))
                .addGap(18, 18, 18)
                .addComponent(jButton9)
                .addGap(18, 18, 18)
                .addComponent(jButton27)
                .addGap(0, 12, Short.MAX_VALUE))
        );
        edittransportasiLayout.setVerticalGroup(
            edittransportasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(edittransportasiLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(edittransportasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(jButton6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(edittransportasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(edittransportasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(edittransportasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(edittransportasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(edittransportasiLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel8)
                        .addGroup(edittransportasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(edittransportasiLayout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, edittransportasiLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel9)))
                        .addGap(18, 18, 18)
                        .addGroup(edittransportasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(edittransportasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11)))
                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(edittransportasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton8)
                    .addComponent(jButton7)
                    .addComponent(jButton26)
                    .addComponent(jButton27)
                    .addComponent(jButton9))
                .addGap(37, 37, 37)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(153, Short.MAX_VALUE))
        );

        mainPanel.add(edittransportasi, "card2");

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel12.setText("MEMBUAT RAB AKOMODASI");

        jLabel13.setText("ID Akomodasi");

        jButton10.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1search.png")); // NOI18N
        jButton10.setText("Cari");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jTable3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7", "Title 8"
            }
        ));
        jScrollPane3.setViewportView(jTable3);

        jLabel14.setText("Alamat Hotel");

        jLabel15.setText("Nama Hotel");

        jLabel16.setText("Check-In");

        jLabel17.setText("Check-Out");

        jLabel18.setText("Biaya Akomodasi");

        jLabel19.setText("Biaya Perorang");

        jTextField11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField11ActionPerformed(evt);
            }
        });

        jTextField14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField14ActionPerformed(evt);
            }
        });

        jTextField16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField16ActionPerformed(evt);
            }
        });

        jButton11.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1save.png")); // NOI18N
        jButton11.setText("Simpan");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jButton12.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1delete.png")); // NOI18N
        jButton12.setText("Hapus");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        jButton13.setText("Reset");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        jButton24.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1exit.png")); // NOI18N
        jButton24.setText("Keluar");
        jButton24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton24ActionPerformed(evt);
            }
        });

        jButton25.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1update.png")); // NOI18N
        jButton25.setText("Update");
        jButton25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton25ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout editakomodasiLayout = new javax.swing.GroupLayout(editakomodasi);
        editakomodasi.setLayout(editakomodasiLayout);
        editakomodasiLayout.setHorizontalGroup(
            editakomodasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, editakomodasiLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jButton13)
                .addGap(29, 29, 29))
            .addGroup(editakomodasiLayout.createSequentialGroup()
                .addGroup(editakomodasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(editakomodasiLayout.createSequentialGroup()
                        .addGap(263, 263, 263)
                        .addComponent(jLabel12))
                    .addGroup(editakomodasiLayout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addComponent(jButton10)
                        .addGap(18, 18, 18)
                        .addComponent(jButton11)
                        .addGap(18, 18, 18)
                        .addComponent(jButton25)
                        .addGap(18, 18, 18)
                        .addComponent(jButton12)
                        .addGap(18, 18, 18)
                        .addComponent(jButton24))
                    .addGroup(editakomodasiLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 614, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(editakomodasiLayout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addGroup(editakomodasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextField16, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(editakomodasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(editakomodasiLayout.createSequentialGroup()
                                    .addGroup(editakomodasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel14)
                                        .addComponent(jLabel15)
                                        .addComponent(jLabel16))
                                    .addGroup(editakomodasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(editakomodasiLayout.createSequentialGroup()
                                            .addGap(59, 59, 59)
                                            .addGroup(editakomodasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, editakomodasiLayout.createSequentialGroup()
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addGroup(editakomodasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jTextField12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jTextField13, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addGroup(editakomodasiLayout.createSequentialGroup()
                                    .addGroup(editakomodasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel19)
                                        .addComponent(jLabel18))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(editakomodasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jTextField14, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jTextField15, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                .addContainerGap(87, Short.MAX_VALUE))
        );
        editakomodasiLayout.setVerticalGroup(
            editakomodasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(editakomodasiLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(editakomodasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(editakomodasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14)
                    .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(editakomodasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(editakomodasiLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel15)
                        .addGap(12, 12, 12)
                        .addComponent(jLabel16))
                    .addGroup(editakomodasiLayout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(14, 14, 14)
                        .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(editakomodasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(editakomodasiLayout.createSequentialGroup()
                        .addGroup(editakomodasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(editakomodasiLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel19))
                            .addGroup(editakomodasiLayout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel17)
                        .addGap(18, 18, 18)
                        .addGroup(editakomodasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel18)
                            .addComponent(jTextField15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jTextField16, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(editakomodasiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton24)
                            .addComponent(jButton11)
                            .addComponent(jButton10)
                            .addComponent(jButton25)
                            .addComponent(jButton12))
                        .addGap(46, 46, 46)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 181, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, editakomodasiLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton13)))
                .addContainerGap())
        );

        mainPanel.add(editakomodasi, "card2");

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel21.setText("MEMBUAT RAB AKOMODASI");

        jLabel22.setText("ID Perjalanan");

        jButton14.setText("Cari");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        jTable4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7", "Title 8"
            }
        ));
        jScrollPane4.setViewportView(jTable4);

        jLabel23.setText("Tanggal Selesai");

        jLabel24.setText("Tanggal Mulai");

        jLabel25.setText("Keperluan");

        jLabel26.setText("Tujuan");

        jLabel27.setText("Total Pegawai");

        jLabel28.setText("Rute Perjalanan");

        jTextField19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField19ActionPerformed(evt);
            }
        });

        jTextField22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField22ActionPerformed(evt);
            }
        });

        jTextField24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField24ActionPerformed(evt);
            }
        });

        jButton15.setText("Simpan");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        jButton16.setText("Hapus");
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });

        jButton17.setText("Reset");
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });

        jButton28.setText("Update");
        jButton28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton28ActionPerformed(evt);
            }
        });

        jButton29.setText("Keluar");
        jButton29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton29ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout editperjalananLayout = new javax.swing.GroupLayout(editperjalanan);
        editperjalanan.setLayout(editperjalananLayout);
        editperjalananLayout.setHorizontalGroup(
            editperjalananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(editperjalananLayout.createSequentialGroup()
                .addGroup(editperjalananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(editperjalananLayout.createSequentialGroup()
                        .addGroup(editperjalananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(editperjalananLayout.createSequentialGroup()
                                .addGap(263, 263, 263)
                                .addComponent(jLabel21))
                            .addGroup(editperjalananLayout.createSequentialGroup()
                                .addGap(52, 52, 52)
                                .addGroup(editperjalananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jButton15)
                                    .addGroup(editperjalananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(editperjalananLayout.createSequentialGroup()
                                            .addComponent(jLabel28)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jTextField24, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(editperjalananLayout.createSequentialGroup()
                                            .addComponent(jLabel27)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jTextField23, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(editperjalananLayout.createSequentialGroup()
                                            .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jTextField22, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(editperjalananLayout.createSequentialGroup()
                                            .addGroup(editperjalananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel23)
                                                .addComponent(jLabel24)
                                                .addComponent(jLabel25))
                                            .addGroup(editperjalananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(editperjalananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addGroup(editperjalananLayout.createSequentialGroup()
                                                        .addGap(54, 54, 54)
                                                        .addComponent(jTextField18, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, editperjalananLayout.createSequentialGroup()
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(jTextField20, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                .addGroup(editperjalananLayout.createSequentialGroup()
                                                    .addGap(54, 54, 54)
                                                    .addComponent(jTextField21, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, editperjalananLayout.createSequentialGroup()
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(jTextField19, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                                .addGap(18, 18, 18)
                                .addGroup(editperjalananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(editperjalananLayout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addComponent(jButton14))
                                    .addGroup(editperjalananLayout.createSequentialGroup()
                                        .addComponent(jButton28)
                                        .addGap(0, 0, Short.MAX_VALUE)))))
                        .addGap(169, 169, 169))
                    .addGroup(editperjalananLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton16)
                        .addGap(18, 18, 18)
                        .addComponent(jButton17)))
                .addGap(18, 18, 18)
                .addComponent(jButton29)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(editperjalananLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4))
        );
        editperjalananLayout.setVerticalGroup(
            editperjalananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(editperjalananLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(editperjalananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22)
                    .addComponent(jButton14))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(editperjalananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(jTextField19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(editperjalananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel24)
                    .addComponent(jTextField20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(editperjalananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(jTextField21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(editperjalananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(editperjalananLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel26)
                        .addGroup(editperjalananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(editperjalananLayout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(jTextField23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, editperjalananLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel27)))
                        .addGap(18, 18, 18)
                        .addGroup(editperjalananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextField24, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel28))
                        .addGap(56, 56, 56)
                        .addGroup(editperjalananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton15)
                            .addComponent(jButton16)
                            .addComponent(jButton17)
                            .addComponent(jButton28)
                            .addComponent(jButton29)))
                    .addComponent(jTextField22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(163, Short.MAX_VALUE))
        );

        mainPanel.add(editperjalanan, "card2");

        jLabel29.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel29.setText("MEMBUAT RAB ");

        jLabel30.setText("ID RAB");

        jButton18.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1search.png")); // NOI18N
        jButton18.setText("Cari");
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });

        jTable5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jTable5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7", "Title 8"
            }
        ));
        jScrollPane5.setViewportView(jTable5);

        jLabel31.setText("Estimasi Akomodasi");

        jLabel32.setText("Estimasi Transportasi");

        jLabel33.setText("Estimasi Harian");

        jLabel34.setText("Estimasi Perorang");

        jLabel35.setText("Total RAB");

        jLabel36.setText("Tanggal Pengajuan");

        jTextField26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField26ActionPerformed(evt);
            }
        });

        jTextField28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField28ActionPerformed(evt);
            }
        });

        jTextField29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField29ActionPerformed(evt);
            }
        });

        jTextField31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField31ActionPerformed(evt);
            }
        });

        jButton19.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1save.png")); // NOI18N
        jButton19.setText("Simpan");
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });

        jButton20.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1delete.png")); // NOI18N
        jButton20.setText("Hapus");
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });

        jButton21.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1reset.png")); // NOI18N
        jButton21.setText("Reset");
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });

        jButton22.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1update.png")); // NOI18N
        jButton22.setText("Update");
        jButton22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton22ActionPerformed(evt);
            }
        });

        jButton23.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1exit.png")); // NOI18N
        jButton23.setText("Keluar");
        jButton23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton23ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout editrabLayout = new javax.swing.GroupLayout(editrab);
        editrab.setLayout(editrabLayout);
        editrabLayout.setHorizontalGroup(
            editrabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(editrabLayout.createSequentialGroup()
                .addGroup(editrabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(editrabLayout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addGroup(editrabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel37)
                            .addGroup(editrabLayout.createSequentialGroup()
                                .addGroup(editrabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel31)
                                    .addComponent(jLabel32)
                                    .addComponent(jLabel33)
                                    .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel35)
                                    .addComponent(jLabel36))
                                .addGap(32, 32, 32)
                                .addGroup(editrabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextField25, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField26, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField27, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField28, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField29, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField30, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField31, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(editrabLayout.createSequentialGroup()
                                .addGap(48, 48, 48)
                                .addComponent(jButton18)
                                .addGap(18, 18, 18)
                                .addComponent(jButton19)
                                .addGap(18, 18, 18)
                                .addComponent(jButton22)
                                .addGap(18, 18, 18)
                                .addComponent(jButton21)
                                .addGap(18, 18, 18)
                                .addComponent(jButton20)
                                .addGap(18, 18, 18)
                                .addComponent(jButton23)))
                        .addGap(0, 7, Short.MAX_VALUE))
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, editrabLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel29)
                .addGap(282, 282, 282))
        );
        editrabLayout.setVerticalGroup(
            editrabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(editrabLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(editrabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(editrabLayout.createSequentialGroup()
                        .addGroup(editrabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel30))
                        .addGap(14, 14, 14)
                        .addGroup(editrabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel31)
                            .addComponent(jTextField26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(14, 14, 14)
                        .addGroup(editrabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel32)
                            .addComponent(jTextField27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(14, 14, 14)
                        .addGroup(editrabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel33)
                            .addComponent(jTextField28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(14, 14, 14)
                        .addGroup(editrabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel34))
                        .addGap(14, 14, 14)
                        .addGroup(editrabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField30, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel35))
                        .addGap(14, 14, 14)
                        .addGroup(editrabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField31, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel36))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel37)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(editrabLayout.createSequentialGroup()
                        .addGap(292, 292, 292)
                        .addGroup(editrabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton18)
                            .addComponent(jButton22)
                            .addComponent(jButton19)
                            .addComponent(jButton23)
                            .addComponent(jButton20)
                            .addComponent(jButton21))
                        .addGap(51, 51, 51)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 313, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        mainPanel.add(editrab, "card2");

        add(mainPanel, "card2");
    }// </editor-fold>//GEN-END:initComponents

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
    mainPanel.removeAll();
    mainPanel.repaint();
    mainPanel.revalidate();
    
    mainPanel.add(editperjalanan);
    mainPanel.repaint();
    mainPanel.revalidate();

    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
    mainPanel.removeAll();
    mainPanel.repaint();
    mainPanel.revalidate();
    
    mainPanel.add(edittransportasi);
    mainPanel.repaint();
    mainPanel.revalidate();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jTextField6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField6ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement
    String query = "SELECT * FROM `transportasi` WHERE id_transportasi = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);
    preparedStatement.setString(1, jTextField2.getText()); // Mengisi parameter query

    // Menjalankan query
    ResultSet rs = preparedStatement.executeQuery();

    // Membuat model untuk JTable
    DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Transportasi");
        tbl.addColumn("Nomor Tiket");
        tbl.addColumn("Jenis Transportasi");
        tbl.addColumn("Biaya Perorang");
        tbl.addColumn("Tanggal Berangkat");
        tbl.addColumn("Total Transportasi");
        tbl.addColumn("Estimasi Waktu");

    

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_transportasi"),
        rs.getString("nomor_tiket"),
        rs.getString("jenis_transportasi"),
        rs.getString("biaya_perorang"),
        rs.getString("waktu_berangkat"),
        rs.getString("total_transportasi"),
        rs.getString("estimasi_waktu"),
        });
    }


    // Menampilkan data di JTable
    jTable2.setModel(tbl);

    // Menutup ResultSet dan PreparedStatement
    rs.close();
    preparedStatement.close();
    conn.close();
} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
           
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
    try {
    // Membuat koneksi ke database
    java.sql.Connection conn = (Connection) konektor.koneksiDB();
    
    // SQL query dengan placeholder untuk parameter
    String sql = "INSERT INTO `transportasi`(`id_transportasi`, `nomor_tiket`, `jenis_transportasi`, `biaya_transportasi`, "
            + "`biaya_perorang`, `waktu_berangkat`, `total_transportasi`, `estimasi_waktu`) "
            + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    
    // Menggunakan PreparedStatement untuk mencegah SQL Injection
    java.sql.PreparedStatement pst = conn.prepareStatement(sql);
    
    // Mengatur parameter untuk PreparedStatement
    pst.setString(1, jTextField2.getText());  
    pst.setString(2, jTextField3.getText());  
    pst.setString(3, jTextField4.getText());  
    pst.setString(4, jTextField5.getText());  
    pst.setString(5, jTextField6.getText());  
    pst.setString(6, jTextField7.getText());  
    pst.setString(7, jTextField8.getText());
    pst.setString(8, jTextField9.getText());
    
    // Menjalankan perintah SQL
    pst.execute();
    
    // Memanggil method untuk memperbarui tampilan tabel atau lainnya
    datatable3();
    
    // Menampilkan pesan sukses
    JOptionPane.showMessageDialog(null, "Penyimpanan Data Berhasil");
} catch (Exception e) {
    // Menampilkan pesan error jika ada kesalahan
    JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
}
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
    try {
    Connection kkk = konektor.koneksiDB();
    String sql = "DELETE FROM transportasi WHERE id_transportasi = '" + jTextField2.getText() + "'";
    
    PreparedStatement preparedStatement = kkk.prepareStatement(sql);
    preparedStatement.executeUpdate(); // Menjalankan query DELETE
    
    preparedStatement.close();
    kkk.close();
    datatable3();
    JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
    
    jTextField2.setText("");
    jTextField3.setText("");
    jTextField4.setText("");
    jTextField5.setText("");
    jTextField6.setText("");
    jTextField7.setText("");
    jTextField8.setText("");
    jTextField9.setText("");
    datatable3();
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jTextField8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField8ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
   try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement
    String query = "SELECT * FROM akomodasi WHERE id_akomodasi = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);
    preparedStatement.setString(1, jTextField10.getText()); // Mengisi parameter query

    // Menjalankan query
    ResultSet rs = preparedStatement.executeQuery();

    // Membuat model untuk JTable
    DefaultTableModel tbl = new DefaultTableModel();
    tbl.addColumn("ID Akomodasi");
    tbl.addColumn("Alamat Hotel");
    tbl.addColumn("Nama Hotel");
    tbl.addColumn("Tanggal Check-In");
    tbl.addColumn("Biaya Perorangan");
    tbl.addColumn("Tanggal Check-Out");
    tbl.addColumn("Biaya Akomodasi");

    // Mengisi data ke model
    while (rs.next()) {
        tbl.addRow(new Object[]{
            rs.getString("id_akomodasi"),
            rs.getString("alamat_hotel"),
            rs.getString("nama_hotel"),
            rs.getString("tanggal_check_in"),
            rs.getString("biaya_perorang"),
            rs.getString("tanggal_check_out"),
            rs.getString("biaya_akomodasi"),
        });
    }

    // Menampilkan data di JTable
    jTable3.setModel(tbl);

    // Menutup ResultSet dan PreparedStatement
    rs.close();
    preparedStatement.close();
    conn.close();
} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}

    }//GEN-LAST:event_jButton10ActionPerformed

    private void jTextField11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField11ActionPerformed

    private void jTextField14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField14ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField14ActionPerformed

    private void jTextField16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField16ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField16ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL untuk INSERT
    String query = "INSERT INTO akomodasi (id_akomodasi,alamat_hotel, nama_hotel, tanggal_check_in, biaya_perorang, tanggal_check_out, biaya_akomodasi) " +
                   "VALUES (?, ? , ?, ?, ?, ?, ?)";
    PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dengan data dari form
    preparedStatement.setString(1, jTextField10.getText()); 
    preparedStatement.setString(2, jTextField11.getText()); 
    preparedStatement.setString(3, jTextField12.getText()); 
    preparedStatement.setString(4, jTextField13.getText()); 
    preparedStatement.setString(5, jTextField14.getText()); 
    preparedStatement.setString(6, jTextField15.getText()); 
    preparedStatement.setString(7, jTextField16.getText());
    // Menjalankan query
    int rowsInserted = preparedStatement.executeUpdate(); 
    if (rowsInserted > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil ditambahkan!");
    }
    datatable3();
    // Menutup PreparedStatement dan koneksi
    preparedStatement.close();
    conn.close();
} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}

    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
try {
    Connection kkk = konektor.koneksiDB();
    String sql = "DELETE FROM akomodasi WHERE id_akomodasi = '" + jTextField10.getText() + "'";
    
    PreparedStatement preparedStatement = kkk.prepareStatement(sql);
    preparedStatement.executeUpdate(); // Menjalankan query DELETE
    
    preparedStatement.close();
    kkk.close();
    datatable3();
    JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}

    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
    jTextField11.setText("");
    jTextField12.setText("");
    jTextField13.setText("");
    jTextField14.setText("");
    jTextField15.setText("");
    jTextField16.setText("");
    datatable2();
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
    mainPanel.removeAll();
    mainPanel.repaint();
    mainPanel.revalidate();
    
    mainPanel.add(editakomodasi);
    mainPanel.repaint();
    mainPanel.revalidate();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL untuk SELECT
    String query = "SELECT * FROM `perjalanan` WHERE id_perjalanan = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dengan ID perjalanan dari input
    preparedStatement.setString(1, jTextField18.getText()); // id_perjalanan

    // Menjalankan query
    ResultSet rs = preparedStatement.executeQuery();

    // Membuat model untuk JTable
    DefaultTableModel tbl = new DefaultTableModel();
    tbl.addColumn("ID Perjalanan");
    tbl.addColumn("Tanggal Mulai");
    tbl.addColumn("Tanggal Selesai");
    tbl.addColumn("Keperluan");
    tbl.addColumn("Tujuan");
    tbl.addColumn("Total Pegawai");
    tbl.addColumn("Rute Perjalanan");

    // Memasukkan data dari ResultSet ke model tabel
    while (rs.next()) {
        tbl.addRow(new Object[]{
            rs.getString("id_perjalanan"),
            rs.getString("tanggal_mulai"),
            rs.getString("tanggal_selesai"),
            rs.getString("keperluan"),
            rs.getString("tujuan"),
            rs.getString("total_pegawai"),
            rs.getString("rute_perjalanan")
        });
    }

    // Menampilkan data di JTable
    jTable4.setModel(tbl);

    // Menutup resources
    rs.close();
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}    // TODO add your handling code here:
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jTextField19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField19ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField19ActionPerformed

    private void jTextField22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField22ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField22ActionPerformed

    private void jTextField24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField24ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField24ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL untuk INSERT
    String query = "INSERT INTO perjalanan(id_perjalanan, tanggal_mulai, tanggal_selesai, keperluan, tujuan, total_pegawai, rute_perjalanan) " +
                   "VALUES (?, ? , ?, ?, ?, ?, ?)";
    PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dengan data dari form
    preparedStatement.setString(1, jTextField18.getText()); 
    preparedStatement.setString(2, jTextField19.getText()); 
    preparedStatement.setString(3, jTextField20.getText()); 
    preparedStatement.setString(4, jTextField21.getText()); 
    preparedStatement.setString(5, jTextField22.getText()); 
    preparedStatement.setString(6, jTextField23.getText()); 
    preparedStatement.setString(7, jTextField24.getText());
    // Menjalankan query
    int rowsInserted = preparedStatement.executeUpdate(); 
    if (rowsInserted > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil ditambahkan!");
    }
    datatable4();
    // Menutup PreparedStatement dan koneksi
    preparedStatement.close();
    conn.close();
} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}

    }//GEN-LAST:event_jButton15ActionPerformed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
    try {
    Connection kkk = konektor.koneksiDB();
    String sql = "DELETE FROM perjalanan WHERE id_perjalanan = '" + jTextField18.getText() + "'";
    
    PreparedStatement preparedStatement = kkk.prepareStatement(sql);
    preparedStatement.executeUpdate(); // Menjalankan query DELETE
    
    preparedStatement.close();
    kkk.close();
    datatable4();
    JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
    jTextField18.setText("");
    jTextField19.setText("");
    jTextField20.setText("");
    jTextField21.setText("");
    jTextField22.setText("");
    jTextField23.setText("");
    jTextField24.setText("");
    datatable4();
    }//GEN-LAST:event_jButton17ActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement
    String query = "SELECT *" +
                   "FROM rab " +
                   "WHERE id_rab = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);
    preparedStatement.setString(1, jTextField25.getText()); // Mengisi parameter query

    // Menjalankan query
    ResultSet rs = preparedStatement.executeQuery();

    // Membuat model tabel dan menambahkan kolom
    DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("Id RAB");
        tbl.addColumn("Estimasi Biaya Akomodasi");
        tbl.addColumn("Estimasi Biaya Transportasi");
        tbl.addColumn("Estimasi Biaya Harian");
        tbl.addColumn("Estimasi Biaya Perorang");
        tbl.addColumn("Total Rab");
        tbl.addColumn("Tanggal Pengajuan");
        tbl.addColumn("Status");
        jTable5.setModel(tbl); 

    // Mengisi tabel dengan data hasil query
    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_rab"),
        rs.getString("estimasi_biaya_akomodasi"),
        rs.getString("estimasi_biaya_transportasi"),
        rs.getString("estimasi_biaya_harian"),
        rs.getString("estimasi_biaya_perorang"),
        rs.getString("total_rab"),
        rs.getString("tanggal_pengajuan"),
        rs.getString("status_rab"),
        rs.getString("status_pemberian_dana"),
            
        });
    }

    jTable5.setModel(tbl);

    // Menutup koneksi dan statement
    rs.close();
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}
    }//GEN-LAST:event_jButton18ActionPerformed

    private void jTextField26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField26ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField26ActionPerformed

    private void jTextField29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField29ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField29ActionPerformed

    private void jTextField31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField31ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField31ActionPerformed

    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed
try {
    // Membuat koneksi ke database
    java.sql.Connection conn = (Connection) konektor.koneksiDB();
    
    // SQL query dengan placeholder untuk parameter
    String sql = "INSERT INTO `rab`(`id_rab`, `estimasi_biaya_akomodasi`, `estimasi_biaya_transportasi`, "
            + "`estimasi_biaya_harian`, `estimasi_biaya_perorang`, `total_rab`, `tanggal_pengajuan`) "
            + "VALUES (?, ?, ?, ?, ?, ?, ?)";
    
    // Menggunakan PreparedStatement untuk mencegah SQL Injection
    java.sql.PreparedStatement pst = conn.prepareStatement(sql);
    
    // Mengatur parameter untuk PreparedStatement
    pst.setString(1, jTextField25.getText());  // id_rab
    pst.setString(2, jTextField26.getText());  // estimasi_biaya_akomodasi
    pst.setString(3, jTextField27.getText());  // estimasi_biaya_transportasi
    pst.setString(4, jTextField28.getText());  // estimasi_biaya_harian
    pst.setString(5, jTextField29.getText());  // estimasi_biaya_perorang (seharusnya jTextField29, bukan jTextField28)
    pst.setString(6, jTextField30.getText());  // total_rab (misalnya jTextField30 untuk total_rab)
    pst.setString(7, jTextField31.getText());  // tanggal_pengajuan (misalnya jTextField31 untuk tanggal_pengajuan)
    
    // Menjalankan perintah SQL
    pst.execute();
    
    // Memanggil method untuk memperbarui tampilan tabel atau lainnya
    datatable1();
    
    // Menampilkan pesan sukses
    JOptionPane.showMessageDialog(null, "Penyimpanan Data Berhasil");
} catch (Exception e) {
    // Menampilkan pesan error jika ada kesalahan
    JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
}

    }//GEN-LAST:event_jButton19ActionPerformed

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
   try {
    // Koneksi ke database
    java.sql.Connection conn = (Connection) konektor.koneksiDB();
    
    // SQL query untuk DELETE dengan placeholder parameter
    String sql = "DELETE FROM `rab` WHERE id_rab = ?";
    
    // Menggunakan PreparedStatement untuk menghindari SQL Injection
    java.sql.PreparedStatement pst = conn.prepareStatement(sql);
    
    // Mengatur parameter dengan nilai dari JTextField
    pst.setString(1, jTextField25.getText());
    
    // Menjalankan query DELETE
    int rowsAffected = pst.executeUpdate();
    
    // Mengecek hasil operasi
    if (rowsAffected > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil dihapus");
    } else {
        JOptionPane.showMessageDialog(null, "ID RAB tidak ditemukan");
    }
} catch (Exception e) {
    JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
}

    }//GEN-LAST:event_jButton20ActionPerformed

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
    jTextField25.setText("");
    jTextField26.setText("");
    jTextField27.setText("");
    jTextField28.setText("");
    jTextField29.setText("");
    jTextField30.setText("");
    jTextField31.setText("");
    datatable1();
    }//GEN-LAST:event_jButton21ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    mainPanel.removeAll();
    mainPanel.repaint();
    mainPanel.revalidate();
    
    mainPanel.add(editrab);
    mainPanel.repaint();
    mainPanel.revalidate();

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton22ActionPerformed
    try {
    // Koneksi ke database
    java.sql.Connection ok = (Connection) konektor.koneksiDB();
    
    // SQL query untuk UPDATE dengan parameter placeholder
    String sql = "UPDATE `rab` SET `estimasi_biaya_akomodasi`=?, `estimasi_biaya_transportasi`=?, `estimasi_biaya_harian`=?, `estimasi_biaya_perorang`=?, `total_rab`=?, `tanggal_pengajuan`=? WHERE `id_rab`=?";
    
    // Menggunakan PreparedStatement untuk menghindari SQL Injection
    java.sql.PreparedStatement pst = ok.prepareStatement(sql);
    
    // Mengatur parameter untuk PreparedStatement
    pst.setString(1, jTextField26.getText());  // estimasi_biaya_akomodasi
    pst.setString(2, jTextField27.getText());  // estimasi_biaya_transportasi
    pst.setString(3, jTextField28.getText());  // estimasi_biaya_harian
    pst.setString(4, jTextField29.getText());  // estimasi_biaya_perorang
    pst.setString(5, jTextField30.getText());  // total_rab
    pst.setString(6, jTextField31.getText());  // tanggal_pengajuan
    pst.setString(7, jTextField25.getText());  // id_rab (untuk WHERE)

    // Menjalankan query UPDATE
    int rowsAffected = pst.executeUpdate();
    
    // Mengecek hasil operasi
    if (rowsAffected > 0) {
        datatable1();  // Memperbarui tabel jika diperlukan
        JOptionPane.showMessageDialog(null, "Penyimpanan Data Berhasil");
    } else {
        JOptionPane.showMessageDialog(null, "Data tidak ditemukan atau tidak ada perubahan");
    }
} catch (Exception e) {
    JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
}

    }//GEN-LAST:event_jButton22ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL dengan PreparedStatement
    String query = "SELECT *" +
                   "FROM rab " +
                   "WHERE id_rab = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);
    preparedStatement.setString(1, jTextField1.getText()); // Mengisi parameter query

    // Menjalankan query
    ResultSet rs = preparedStatement.executeQuery();

    // Membuat model tabel dan menambahkan kolom
    DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("Id RAB");
        tbl.addColumn("Estimasi Biaya Akomodasi");
        tbl.addColumn("Estimasi Biaya Transportasi");
        tbl.addColumn("Estimasi Biaya Harian");
        tbl.addColumn("Estimasi Biaya Perorang");
        tbl.addColumn("Total Rab");
        tbl.addColumn("Tanggal Pengajuan");
        tbl.addColumn("Status");
        jTable1.setModel(tbl); 

    // Mengisi tabel dengan data hasil query
    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_rab"),
        rs.getString("estimasi_biaya_akomodasi"),
        rs.getString("estimasi_biaya_transportasi"),
        rs.getString("estimasi_biaya_harian"),
        rs.getString("estimasi_biaya_perorang"),
        rs.getString("total_rab"),
        rs.getString("tanggal_pengajuan"),
        rs.getString("status_rab"),
        rs.getString("status_pemberian_dana"),
            
        });
    }

    jTable1.setModel(tbl);

    // Menutup koneksi dan statement
    rs.close();
    preparedStatement.close();
    conn.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
}
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton23ActionPerformed
    mainPanel.removeAll();
    mainPanel.repaint();
    mainPanel.revalidate();
    
    mainPanel.add(Buat_RAB);
    mainPanel.repaint();
    mainPanel.revalidate();
    }//GEN-LAST:event_jButton23ActionPerformed

    private void jButton24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton24ActionPerformed
    mainPanel.removeAll();
    mainPanel.repaint();
    mainPanel.revalidate();
    
    mainPanel.add(Buat_RAB);
    mainPanel.repaint();
    mainPanel.revalidate();
    }//GEN-LAST:event_jButton24ActionPerformed

    private void jButton25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton25ActionPerformed
    try {
    // Koneksi ke database
    java.sql.Connection ok = (Connection) konektor.koneksiDB();
    
    // SQL query untuk UPDATE dengan parameter placeholder
    String sql = "UPDATE `akomodasi` SET `alamat_hotel`=?, `nama_hotel`=?, `tanggal_check_in`=?, `biaya_perorang`=?, `tanggal_check_out`=?, `biaya_akomodasi`=? WHERE `id_akomodasi`=?";
    
    // Menggunakan PreparedStatement untuk menghindari SQL Injection
    java.sql.PreparedStatement pst = ok.prepareStatement(sql);
    
    // Mengatur parameter untuk PreparedStatement
    pst.setString(1, jTextField11.getText());  
    pst.setString(2, jTextField12.getText());  
    pst.setString(3, jTextField13.getText());  
    pst.setString(4, jTextField14.getText());  
    pst.setString(5, jTextField15.getText());  
    pst.setString(6, jTextField16.getText());  
    pst.setString(7, jTextField10.getText());  

    // Menjalankan query UPDATE
    int rowsAffected = pst.executeUpdate();
    
    // Mengecek hasil operasi
    if (rowsAffected > 0) {
        datatable2();  // Memperbarui tabel jika diperlukan
        JOptionPane.showMessageDialog(null, "Penyimpanan Data Berhasil");
    } else {
        JOptionPane.showMessageDialog(null, "Data tidak ditemukan atau tidak ada perubahan");
    }
} catch (Exception e) {
    JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
}
    }//GEN-LAST:event_jButton25ActionPerformed

    private void jButton26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton26ActionPerformed
try {
    // Validasi input
    if (jTextField2.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(null, "ID Transportasi tidak boleh kosong!");
        return;
    }

    

    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL untuk UPDATE
    String query = "UPDATE `transportasi` SET nomor_tiket = ?, jenis_transportasi = ?, biaya_transportasi = ?, biaya_perorang = ?, "
                 + "waktu_berangkat = ?, total_transportasi = ?, estimasi_waktu = ? WHERE id_transportasi = ?";

    // Menggunakan PreparedStatement
    PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dari input user
    preparedStatement.setString(1, jTextField3.getText());  // nomor_tiket
    preparedStatement.setString(2, jTextField4.getText());  // jenis_transportasi
    preparedStatement.setString(3, jTextField5.getText());  // biaya_transportasi
    preparedStatement.setString(4, jTextField6.getText());  // biaya_perorang
    preparedStatement.setString(5, jTextField7.getText());  // waktu_berangkat
    preparedStatement.setString(6, jTextField8.getText());  // total_transportasi
    preparedStatement.setString(7, jTextField9.getText());  // estimasi_waktu
    preparedStatement.setString(8, jTextField2.getText()); // id_transportasi (kondisi WHERE)

    // Menjalankan perintah SQL
    int rowsUpdated = preparedStatement.executeUpdate();

    // Memberikan feedback pada user
    if (rowsUpdated > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil diperbarui!");
    } else {
        JOptionPane.showMessageDialog(null, "Data dengan ID Transportasi tersebut tidak ditemukan.");
    }

    // Menutup resource
    preparedStatement.close();
    conn.close();
} catch (Exception e) {
    // Menangani error dari database
    JOptionPane.showMessageDialog(null, "Database Error: " + e.getMessage());
} 
    }//GEN-LAST:event_jButton26ActionPerformed

    private void jButton27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton27ActionPerformed
    mainPanel.removeAll();
    mainPanel.repaint();
    mainPanel.revalidate();
    
    mainPanel.add(Buat_RAB);
    mainPanel.repaint();
    mainPanel.revalidate();
    }//GEN-LAST:event_jButton27ActionPerformed

    private void jButton29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton29ActionPerformed
    mainPanel.removeAll();
    mainPanel.repaint();
    mainPanel.revalidate();
    
    mainPanel.add(Buat_RAB);
    mainPanel.repaint();
    mainPanel.revalidate();
    }//GEN-LAST:event_jButton29ActionPerformed

    private void jButton28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton28ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL untuk UPDATE
    String query = "UPDATE `perjalanan` SET tanggal_mulai = ?, tanggal_selesai = ?, keperluan = ?, tujuan = ?, total_pegawai = ?, rute_perjalanan = ? " +
                   "WHERE id_perjalanan = ?";
    PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dengan data dari form
    preparedStatement.setString(1, jTextField19.getText()); // tanggal_mulai
    preparedStatement.setString(2, jTextField20.getText()); // tanggal_selesai
    preparedStatement.setString(3, jTextField21.getText()); // keperluan
    preparedStatement.setString(4, jTextField22.getText()); // tujuan
    preparedStatement.setString(5, jTextField23.getText()); // total_pegawai
    preparedStatement.setString(6, jTextField24.getText()); // rute_perjalanan
    preparedStatement.setString(7, jTextField18.getText()); // id_perjalanan (kondisi WHERE)

    // Menjalankan query
    int rowsUpdated = preparedStatement.executeUpdate();
    if (rowsUpdated > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil diperbarui!");
    } else {
        JOptionPane.showMessageDialog(null, "ID Perjalanan tidak ditemukan. Data tidak diperbarui.");
    }

    // Memperbarui tabel tampilan jika ada
    datatable4();

    // Menutup PreparedStatement dan koneksi
    preparedStatement.close();
    conn.close();
} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}

    }//GEN-LAST:event_jButton28ActionPerformed

    private void jTextField28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField28ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField28ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Buat_RAB;
    private javax.swing.JPanel editakomodasi;
    private javax.swing.JPanel editperjalanan;
    private javax.swing.JPanel editrab;
    private javax.swing.JPanel edittransportasi;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton25;
    private javax.swing.JButton jButton26;
    private javax.swing.JButton jButton27;
    private javax.swing.JButton jButton28;
    private javax.swing.JButton jButton29;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable4;
    private javax.swing.JTable jTable5;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField16;
    private javax.swing.JTextField jTextField18;
    private javax.swing.JTextField jTextField19;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField20;
    private javax.swing.JTextField jTextField21;
    private javax.swing.JTextField jTextField22;
    private javax.swing.JTextField jTextField23;
    private javax.swing.JTextField jTextField24;
    private javax.swing.JTextField jTextField25;
    private javax.swing.JTextField jTextField26;
    private javax.swing.JTextField jTextField27;
    private javax.swing.JTextField jTextField28;
    private javax.swing.JTextField jTextField29;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField30;
    private javax.swing.JTextField jTextField31;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JPanel mainPanel;
    // End of variables declaration//GEN-END:variables
}
