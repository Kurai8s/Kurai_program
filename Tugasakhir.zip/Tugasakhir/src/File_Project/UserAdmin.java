package File_Project;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Asus
 */
public class UserAdmin {
    private static String u_ID;
    private static String u_Nama;
    private static String u_TTL;
    private static String u_Telp;
    private static String u_Alamat;
    private static String u_Email   ;
    private static String u_Nik;

    
    public static String getU_ID() {
        return u_ID;
    }

    public static void setU_ID(String u_ID) {
        UserAdmin.u_ID = u_ID;
    }
    
    
    public static String getU_Nama() {
        return u_Nama;
    }

    public static void setU_Nama(String u_Nama) {
        UserAdmin.u_Nama = u_Nama;
    }

    public static String getU_TTL() {
        return u_TTL;
    }

    public static void setU_TTL(String u_TTL) {
        UserAdmin.u_TTL = u_TTL;
        
    }
    
    
    public static String getU_Telp() {
        return u_Telp;
    }

    public static void setU_Telp(String u_Telp) {
        UserAdmin.u_Telp = u_Telp;
    }

    public static String getU_Alamat() {
        return u_Alamat;
    }

    public static void setU_Alamat(String u_Alamat) {
        UserAdmin.u_Alamat = u_Alamat;
    }

    public static String getU_Email() {
        return u_Email;
    }

    public static void setU_Email(String u_Email) {
        UserAdmin.u_Email = u_Email;
    }

    public static String getU_Nik() {
        return u_Nik;
    }

    public static void setU_Nik(String u_Nik) {
        UserAdmin.u_Nik = u_Nik;
    }
}
