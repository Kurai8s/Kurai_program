package File_Project;


import Koneksi.konektor;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */

/**
 *
 * @author Asus
 */
public class datastaff extends javax.swing.JPanel {

    /**
     * Creates new form datastaff
     */
    public datastaff() {
        initComponents();
        datadirektur();
        datasekertaris();
        databendahara();
        datapegawai();
        dataadmin();
    }

    public void datadirektur(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Direktur");
        tbl.addColumn("Nama");
        tbl.addColumn("Email");
        tbl.addColumn("Tanggal Lahir");
        tbl.addColumn("Alamat");
        tbl.addColumn("Gaji");
        tbl.addColumn("Nomor Telpon");
        tbl.addColumn("ID Staff");
        jTable1.setModel(tbl); 
       
           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `direktur`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_direktur"),
        rs.getString("nama_direktur"),
        rs.getString("email"),
        rs.getString("tanggal_lahir"),
        rs.getString("alamat"),
        rs.getString("gaji"),
        rs.getString("nomor_telpon"),
        rs.getString("id_staff"),
        
        });
    }

    jTable1.setModel(tbl);

    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }
    
    
    
    public void datasekertaris(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Sekertaris");
        tbl.addColumn("Nama");
        tbl.addColumn("Tanggal Lahir");
        tbl.addColumn("Nomor Telpon");
        tbl.addColumn("Email");
        tbl.addColumn("Gaji");
        tbl.addColumn("ID Surat Tugas");
        tbl.addColumn("ID Hasil Laporan");
        
        jTable2.setModel(tbl); 
           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `sekertaris`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_sekertaris"),
        rs.getString("nama"),
        rs.getString("tanggal_lahir"),
        rs.getString("nomor_telpon"),
        rs.getString("email"),
        rs.getString("gaji"),
        rs.getString("id_surat_tugas"),
        rs.getString("id_hasil_laporan"),
        });
    }

    jTable2.setModel(tbl);

    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }
    
    
    public void databendahara(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Bendahara");
        tbl.addColumn("Nama");
        tbl.addColumn("Email");
        tbl.addColumn("Nomor Telpon");
        tbl.addColumn("Tanggal Mulai Jabatan");
        tbl.addColumn("Saldo Keuangan");
        tbl.addColumn("Jumlah Transaksi");
        
        jTable3.setModel(tbl); 
           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `bendahara`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_bendahara"),
        rs.getString("Nama_Bendahara"),
        rs.getString("Email_Bendahara"),
        rs.getString("Telepon_Bendahara"),
        rs.getString("Tanggal_Mulai_Jabatan"),
        rs.getString("Saldo_Keuangan"),
        rs.getString("Jumlah_Transaksi"),
        });
    }

    jTable3.setModel(tbl);

    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }
    
    public void datapegawai(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Pegawai");
        tbl.addColumn("Nama");
        tbl.addColumn("Tanggal Lahir");
        tbl.addColumn("Nomor Telpon");
        tbl.addColumn("Alamat");
        tbl.addColumn("Email");
        tbl.addColumn("Jabatan");
        tbl.addColumn("Status Surat Tugas");
        tbl.addColumn("ID Hasil Laporan");
        jTable4.setModel(tbl); 
           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `pegawai`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_pegawai"),
        rs.getString("nama"),
        rs.getString("tanggal_lahir"),
        rs.getString("no_tlp"),
        rs.getString("alamat"),
        rs.getString("email"),
        rs.getString("jabatan"),
        rs.getString("status_surat_tugas"),
        rs.getString("id_hasil_laporan"),
        });
    }

    jTable4.setModel(tbl);

    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }
    
    
    public void dataadmin(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Admin");
        tbl.addColumn("Nama");
        tbl.addColumn("Alamat");
        tbl.addColumn("Email");
        tbl.addColumn("Tanggal Lahir");
        tbl.addColumn("Nomor Telpon");
        tbl.addColumn("Gaji");
        tbl.addColumn("NIK");
        jTable5.setModel(tbl); 
           try {
    Statement s = konektor.koneksiDB().createStatement();
    
    ResultSet rs = s.executeQuery("SELECT * FROM `admin`");

    tbl.setRowCount(0); // Clear existing rows

    while (rs.next()) {
        tbl.addRow(new Object[]{
        rs.getString("id_admin"),
        rs.getString("nama"),
        rs.getString("alamat"),
        rs.getString("email"),
        rs.getString("tanggal_lahir"),
        rs.getString("no_telepon"),
        rs.getString("gaji"),
        rs.getString("nik"),
        });
    }

    jTable5.setModel(tbl);

    // Menutup sumber daya
    rs.close();
    s.close();
    
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
   }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        MainPanel = new javax.swing.JPanel();
        sekertaris = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jTextField9 = new javax.swing.JTextField();
        jTextField10 = new javax.swing.JTextField();
        jTextField11 = new javax.swing.JTextField();
        jTextField12 = new javax.swing.JTextField();
        jTextField13 = new javax.swing.JTextField();
        jTextField14 = new javax.swing.JTextField();
        jTextField15 = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        jTextField16 = new javax.swing.JTextField();
        jButton13 = new javax.swing.JButton();
        bendahara = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jTextField17 = new javax.swing.JTextField();
        jTextField18 = new javax.swing.JTextField();
        jTextField19 = new javax.swing.JTextField();
        jTextField20 = new javax.swing.JTextField();
        jTextField21 = new javax.swing.JTextField();
        jTextField22 = new javax.swing.JTextField();
        jTextField23 = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jButton16 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        jButton19 = new javax.swing.JButton();
        jButton20 = new javax.swing.JButton();
        pegawai = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jTextField24 = new javax.swing.JTextField();
        jTextField25 = new javax.swing.JTextField();
        jTextField26 = new javax.swing.JTextField();
        jTextField27 = new javax.swing.JTextField();
        jTextField28 = new javax.swing.JTextField();
        jTextField29 = new javax.swing.JTextField();
        jTextField30 = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        jButton21 = new javax.swing.JButton();
        jButton22 = new javax.swing.JButton();
        jButton23 = new javax.swing.JButton();
        jButton24 = new javax.swing.JButton();
        jButton25 = new javax.swing.JButton();
        jButton26 = new javax.swing.JButton();
        jButton27 = new javax.swing.JButton();
        jLabel35 = new javax.swing.JLabel();
        jTextField31 = new javax.swing.JTextField();
        jLabel36 = new javax.swing.JLabel();
        jTextField32 = new javax.swing.JTextField();
        admin = new javax.swing.JPanel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jTextField33 = new javax.swing.JTextField();
        jTextField34 = new javax.swing.JTextField();
        jTextField35 = new javax.swing.JTextField();
        jTextField36 = new javax.swing.JTextField();
        jTextField37 = new javax.swing.JTextField();
        jTextField38 = new javax.swing.JTextField();
        jTextField39 = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable5 = new javax.swing.JTable();
        jButton28 = new javax.swing.JButton();
        jButton29 = new javax.swing.JButton();
        jButton30 = new javax.swing.JButton();
        jButton31 = new javax.swing.JButton();
        jButton32 = new javax.swing.JButton();
        jButton33 = new javax.swing.JButton();
        jButton34 = new javax.swing.JButton();
        jLabel45 = new javax.swing.JLabel();
        jTextField40 = new javax.swing.JTextField();
        direktur = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jTextField8 = new javax.swing.JTextField();

        setLayout(new java.awt.CardLayout());

        MainPanel.setLayout(new java.awt.CardLayout());

        jLabel10.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel10.setText("Sekertaris");

        jLabel11.setText("ID Sekertaris");

        jLabel12.setText("Nama");

        jLabel13.setText("Email");

        jLabel14.setText("Tanggal Lahir");

        jLabel15.setText("ID Surat Tugas");

        jLabel16.setText("Gaji");

        jLabel17.setText("Nomor Telpon");

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        jButton7.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1search.png")); // NOI18N
        jButton7.setText("Cari");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1save.png")); // NOI18N
        jButton8.setText("Simpan");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton9.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1update.png")); // NOI18N
        jButton9.setText("Update");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jButton10.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1delete.png")); // NOI18N
        jButton10.setText("Hapus");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jButton11.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1reset.png")); // NOI18N
        jButton11.setText("Reset");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jButton12.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1arrow.png")); // NOI18N
        jButton12.setText("Hal. Selanjutnya");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        jLabel18.setText("ID Hasil Laporan");

        jButton13.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1arrowleft.png")); // NOI18N
        jButton13.setText("Hal. Sebelumnya");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout sekertarisLayout = new javax.swing.GroupLayout(sekertaris);
        sekertaris.setLayout(sekertarisLayout);
        sekertarisLayout.setHorizontalGroup(
            sekertarisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(sekertarisLayout.createSequentialGroup()
                .addGroup(sekertarisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, sekertarisLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton13)
                        .addGap(18, 18, 18)
                        .addComponent(jButton12))
                    .addGroup(sekertarisLayout.createSequentialGroup()
                        .addGroup(sekertarisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(sekertarisLayout.createSequentialGroup()
                                .addGroup(sekertarisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(sekertarisLayout.createSequentialGroup()
                                        .addContainerGap()
                                        .addGroup(sekertarisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel11)
                                            .addComponent(jLabel12)
                                            .addComponent(jLabel14)
                                            .addComponent(jLabel17)
                                            .addComponent(jLabel18)
                                            .addComponent(jLabel13)
                                            .addComponent(jLabel16)
                                            .addComponent(jLabel15))
                                        .addGap(45, 45, 45)
                                        .addGroup(sekertarisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(sekertarisLayout.createSequentialGroup()
                                                .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(62, 62, 62)
                                                .addComponent(jButton7))
                                            .addGroup(sekertarisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addComponent(jTextField16, javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jTextField15, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE))
                                            .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(sekertarisLayout.createSequentialGroup()
                                        .addGap(185, 185, 185)
                                        .addComponent(jButton8)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton9)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton10)))
                                .addGap(18, 18, 18)
                                .addComponent(jButton11))
                            .addGroup(sekertarisLayout.createSequentialGroup()
                                .addGap(42, 42, 42)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 689, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, sekertarisLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel10)
                .addGap(348, 348, 348))
        );
        sekertarisLayout.setVerticalGroup(
            sekertarisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(sekertarisLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel10)
                .addGap(26, 26, 26)
                .addGroup(sekertarisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton7))
                .addGap(18, 18, 18)
                .addGroup(sekertarisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(sekertarisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14))
                .addGap(18, 18, 18)
                .addGroup(sekertarisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17))
                .addGap(18, 18, 18)
                .addGroup(sekertarisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13))
                .addGap(20, 20, 20)
                .addGroup(sekertarisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16))
                .addGap(18, 18, 18)
                .addGroup(sekertarisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15))
                .addGap(20, 20, 20)
                .addGroup(sekertarisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(jTextField16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(63, 63, 63)
                .addGroup(sekertarisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton8)
                    .addComponent(jButton9)
                    .addComponent(jButton10)
                    .addComponent(jButton11))
                .addGap(37, 37, 37)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 92, Short.MAX_VALUE)
                .addGroup(sekertarisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton12)
                    .addComponent(jButton13))
                .addGap(17, 17, 17))
        );

        MainPanel.add(sekertaris, "card2");

        jLabel19.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel19.setText("Bendahara");

        jLabel20.setText("ID Bendahara");

        jLabel21.setText("Nama");

        jLabel22.setText("Tanggal Mulai Jabatan");

        jLabel23.setText("Email");

        jLabel24.setText("Jumlah Transaksi");

        jLabel25.setText("Saldo Keuangan");

        jLabel26.setText("Nomor Telpon");

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(jTable3);

        jButton14.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1search.png")); // NOI18N
        jButton14.setText("Cari");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        jButton15.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1save.png")); // NOI18N
        jButton15.setText("Simpan");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        jButton16.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1update.png")); // NOI18N
        jButton16.setText("Update");
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });

        jButton17.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1delete.png")); // NOI18N
        jButton17.setText("Hapus");
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });

        jButton18.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1reset.png")); // NOI18N
        jButton18.setText("Reset");
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });

        jButton19.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1arrow.png")); // NOI18N
        jButton19.setText("Hal. Selanjutnya");
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });

        jButton20.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1arrowleft.png")); // NOI18N
        jButton20.setText("Hal. Sebelumnya");
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout bendaharaLayout = new javax.swing.GroupLayout(bendahara);
        bendahara.setLayout(bendaharaLayout);
        bendaharaLayout.setHorizontalGroup(
            bendaharaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bendaharaLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel19)
                .addGap(334, 334, 334))
            .addGroup(bendaharaLayout.createSequentialGroup()
                .addGroup(bendaharaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bendaharaLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(bendaharaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel20)
                            .addComponent(jLabel21)
                            .addComponent(jLabel23)
                            .addComponent(jLabel26)
                            .addComponent(jLabel22)
                            .addComponent(jLabel25)
                            .addComponent(jLabel24))
                        .addGap(55, 55, 55)
                        .addGroup(bendaharaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField22, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField20, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField18, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField21, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField23, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField19, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(bendaharaLayout.createSequentialGroup()
                                .addComponent(jTextField17, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(44, 44, 44)
                                .addComponent(jButton14))
                            .addGroup(bendaharaLayout.createSequentialGroup()
                                .addComponent(jButton15)
                                .addGap(18, 18, 18)
                                .addComponent(jButton16)
                                .addGap(18, 18, 18)
                                .addComponent(jButton17)
                                .addGap(18, 18, 18)
                                .addComponent(jButton18))))
                    .addGroup(bendaharaLayout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 659, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(32, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bendaharaLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton20)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton19)
                .addGap(3, 3, 3))
        );
        bendaharaLayout.setVerticalGroup(
            bendaharaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bendaharaLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel19)
                .addGap(18, 18, 18)
                .addGroup(bendaharaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(jTextField17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton14))
                .addGap(18, 18, 18)
                .addGroup(bendaharaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(jTextField18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(bendaharaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel23))
                .addGap(18, 18, 18)
                .addGroup(bendaharaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel26))
                .addGap(18, 18, 18)
                .addGroup(bendaharaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22))
                .addGap(20, 20, 20)
                .addGroup(bendaharaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel25))
                .addGap(18, 18, 18)
                .addGroup(bendaharaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel24))
                .addGap(48, 48, 48)
                .addGroup(bendaharaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton15)
                    .addComponent(jButton16)
                    .addComponent(jButton17)
                    .addComponent(jButton18))
                .addGap(27, 27, 27)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 62, Short.MAX_VALUE)
                .addGroup(bendaharaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton20)
                    .addComponent(jButton19))
                .addGap(26, 26, 26))
        );

        MainPanel.add(bendahara, "card2");

        jLabel27.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel27.setText("Pegawai");

        jLabel28.setText("ID Bendahara");

        jLabel29.setText("Nama");

        jLabel30.setText("Alamat");

        jLabel31.setText("Tanggal Lahir");

        jLabel32.setText("Jabatan");

        jLabel33.setText("Email");

        jLabel34.setText("Nomor Telpon");

        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane4.setViewportView(jTable4);

        jButton21.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1search.png")); // NOI18N
        jButton21.setText("Cari");
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });

        jButton22.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1save.png")); // NOI18N
        jButton22.setText("Simpan");
        jButton22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton22ActionPerformed(evt);
            }
        });

        jButton23.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1update.png")); // NOI18N
        jButton23.setText("Update");
        jButton23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton23ActionPerformed(evt);
            }
        });

        jButton24.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1delete.png")); // NOI18N
        jButton24.setText("Hapus");
        jButton24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton24ActionPerformed(evt);
            }
        });

        jButton25.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1reset.png")); // NOI18N
        jButton25.setText("Reset");
        jButton25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton25ActionPerformed(evt);
            }
        });

        jButton26.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1arrow.png")); // NOI18N
        jButton26.setText("Hal. Selanjutnya");
        jButton26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton26ActionPerformed(evt);
            }
        });

        jButton27.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1arrowleft.png")); // NOI18N
        jButton27.setText("Hal. Sebelumnya");
        jButton27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton27ActionPerformed(evt);
            }
        });

        jLabel35.setText("Status Surat Tugas");

        jLabel36.setText("Status Surat Tugas");

        javax.swing.GroupLayout pegawaiLayout = new javax.swing.GroupLayout(pegawai);
        pegawai.setLayout(pegawaiLayout);
        pegawaiLayout.setHorizontalGroup(
            pegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pegawaiLayout.createSequentialGroup()
                .addGroup(pegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pegawaiLayout.createSequentialGroup()
                        .addGap(0, 434, Short.MAX_VALUE)
                        .addComponent(jButton27)
                        .addGap(18, 18, 18)
                        .addComponent(jButton26))
                    .addGroup(pegawaiLayout.createSequentialGroup()
                        .addGroup(pegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pegawaiLayout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(pegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel27)
                                    .addGroup(pegawaiLayout.createSequentialGroup()
                                        .addGroup(pegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(pegawaiLayout.createSequentialGroup()
                                                .addComponent(jLabel35)
                                                .addGap(34, 34, 34))
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pegawaiLayout.createSequentialGroup()
                                                .addGroup(pegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addComponent(jLabel28, javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel29, javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel31, javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel34, javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel30, javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel33, javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel32, javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel36, javax.swing.GroupLayout.Alignment.LEADING))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                        .addGroup(pegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jTextField29, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jTextField27, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jTextField25, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jTextField28, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jTextField30, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jTextField26, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jTextField31, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(pegawaiLayout.createSequentialGroup()
                                                .addGroup(pegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pegawaiLayout.createSequentialGroup()
                                                        .addComponent(jTextField24, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(jButton21))
                                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pegawaiLayout.createSequentialGroup()
                                                        .addGroup(pegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                            .addComponent(jButton22)
                                                            .addComponent(jTextField32, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGap(18, 18, 18)
                                                        .addComponent(jButton23)))
                                                .addGap(18, 18, 18)
                                                .addComponent(jButton24)))))
                                .addGap(18, 18, 18)
                                .addComponent(jButton25))
                            .addGroup(pegawaiLayout.createSequentialGroup()
                                .addGap(42, 42, 42)
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 645, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        pegawaiLayout.setVerticalGroup(
            pegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pegawaiLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel27)
                .addGap(41, 41, 41)
                .addGroup(pegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel28, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextField24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton21)))
                .addGap(18, 18, 18)
                .addGroup(pegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel29)
                    .addComponent(jTextField25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel31))
                .addGap(18, 18, 18)
                .addGroup(pegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel34))
                .addGap(18, 18, 18)
                .addGroup(pegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel30))
                .addGap(18, 18, 18)
                .addGroup(pegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel33))
                .addGap(18, 18, 18)
                .addGroup(pegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField30, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel32))
                .addGroup(pegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pegawaiLayout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addGroup(pegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField32, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel36)))
                    .addGroup(pegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextField31, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel35)))
                .addGap(58, 58, 58)
                .addGroup(pegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton22)
                    .addComponent(jButton23)
                    .addComponent(jButton24)
                    .addComponent(jButton25))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 52, Short.MAX_VALUE)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addGroup(pegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton26)
                    .addComponent(jButton27))
                .addGap(17, 17, 17))
        );

        MainPanel.add(pegawai, "card2");

        jLabel37.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel37.setText("Admin");

        jLabel38.setText("ID Admin");

        jLabel39.setText("Nama");

        jLabel40.setText("Alamat");

        jLabel41.setText("Tanggal Lahir");

        jLabel42.setText("Gaji");

        jLabel43.setText("Email");

        jLabel44.setText("Nomor Telpon");

        jTable5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane5.setViewportView(jTable5);

        jButton28.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1search.png")); // NOI18N
        jButton28.setText("Cari");
        jButton28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton28ActionPerformed(evt);
            }
        });

        jButton29.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1save.png")); // NOI18N
        jButton29.setText("Simpan");
        jButton29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton29ActionPerformed(evt);
            }
        });

        jButton30.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1update.png")); // NOI18N
        jButton30.setText("Update");
        jButton30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton30ActionPerformed(evt);
            }
        });

        jButton31.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1delete.png")); // NOI18N
        jButton31.setText("Hapus");
        jButton31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton31ActionPerformed(evt);
            }
        });

        jButton32.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1reset.png")); // NOI18N
        jButton32.setText("Reset");
        jButton32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton32ActionPerformed(evt);
            }
        });

        jButton33.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1arrow.png")); // NOI18N
        jButton33.setText("Hal. Selanjutnya");
        jButton33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton33ActionPerformed(evt);
            }
        });

        jButton34.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1arrowleft.png")); // NOI18N
        jButton34.setText("Hal. Sebelumnya");
        jButton34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton34ActionPerformed(evt);
            }
        });

        jLabel45.setText("NIK");

        javax.swing.GroupLayout adminLayout = new javax.swing.GroupLayout(admin);
        admin.setLayout(adminLayout);
        adminLayout.setHorizontalGroup(
            adminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(adminLayout.createSequentialGroup()
                .addGroup(adminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, adminLayout.createSequentialGroup()
                        .addGap(0, 434, Short.MAX_VALUE)
                        .addComponent(jButton34)
                        .addGap(18, 18, 18)
                        .addComponent(jButton33))
                    .addGroup(adminLayout.createSequentialGroup()
                        .addGroup(adminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(adminLayout.createSequentialGroup()
                                .addGroup(adminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, adminLayout.createSequentialGroup()
                                        .addContainerGap()
                                        .addGroup(adminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel38)
                                            .addComponent(jLabel39)
                                            .addComponent(jLabel40)
                                            .addComponent(jLabel43)
                                            .addComponent(jLabel42)
                                            .addComponent(jLabel45)
                                            .addComponent(jLabel41)
                                            .addComponent(jLabel44))
                                        .addGap(34, 34, 34)
                                        .addGroup(adminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(jTextField39, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
                                            .addComponent(jTextField38, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jTextField37, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jTextField36, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jTextField35, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jTextField34, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jTextField33, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jTextField40))
                                        .addGap(52, 52, 52)
                                        .addComponent(jButton28))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, adminLayout.createSequentialGroup()
                                        .addGap(197, 197, 197)
                                        .addComponent(jButton29)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton30)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton31)))
                                .addGap(18, 18, 18)
                                .addComponent(jButton32))
                            .addGroup(adminLayout.createSequentialGroup()
                                .addGap(42, 42, 42)
                                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 678, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(adminLayout.createSequentialGroup()
                .addGap(364, 364, 364)
                .addComponent(jLabel37)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        adminLayout.setVerticalGroup(
            adminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(adminLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel37)
                .addGap(18, 18, 18)
                .addGroup(adminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel38)
                    .addComponent(jTextField33, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton28))
                .addGap(18, 18, 18)
                .addGroup(adminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel39)
                    .addComponent(jTextField34, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(adminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField35, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel40))
                .addGap(18, 18, 18)
                .addGroup(adminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField36, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel43))
                .addGap(18, 18, 18)
                .addGroup(adminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField37, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel41))
                .addGap(20, 20, 20)
                .addGroup(adminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField38, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel44))
                .addGap(18, 18, 18)
                .addGroup(adminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField39, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel42))
                .addGroup(adminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(adminLayout.createSequentialGroup()
                        .addGap(99, 99, 99)
                        .addGroup(adminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton29)
                            .addComponent(jButton30)
                            .addComponent(jButton31)
                            .addComponent(jButton32)))
                    .addGroup(adminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextField40, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel45)))
                .addGap(35, 35, 35)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 98, Short.MAX_VALUE)
                .addGroup(adminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton33)
                    .addComponent(jButton34))
                .addGap(17, 17, 17))
        );

        MainPanel.add(admin, "card2");

        jLabel1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel1.setText("DIREKTUR");

        jLabel2.setText("ID Direktur");

        jLabel3.setText("Nama");

        jLabel4.setText("Email");

        jLabel5.setText("Tanggal Lahir");

        jLabel6.setText("Alamat");

        jLabel7.setText("Gaji");

        jLabel8.setText("Nomor Telpon");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jButton1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1search.png")); // NOI18N
        jButton1.setText("Cari");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1save.png")); // NOI18N
        jButton2.setText("Simpan");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1update.png")); // NOI18N
        jButton3.setText("Update");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1delete.png")); // NOI18N
        jButton4.setText("Hapus");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1reset.png")); // NOI18N
        jButton5.setText("Reset");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus\\Downloads\\1arrow.png")); // NOI18N
        jButton6.setText("Hal. Selanjutnya");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jLabel9.setText("ID Staff");

        javax.swing.GroupLayout direkturLayout = new javax.swing.GroupLayout(direktur);
        direktur.setLayout(direkturLayout);
        direkturLayout.setHorizontalGroup(
            direkturLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(direkturLayout.createSequentialGroup()
                .addGroup(direkturLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, direkturLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton6))
                    .addGroup(direkturLayout.createSequentialGroup()
                        .addGroup(direkturLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(direkturLayout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(direkturLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel1)
                                    .addGroup(direkturLayout.createSequentialGroup()
                                        .addGroup(direkturLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel2)
                                            .addComponent(jLabel3)
                                            .addComponent(jLabel4)
                                            .addComponent(jLabel5)
                                            .addComponent(jLabel6)
                                            .addComponent(jLabel7)
                                            .addComponent(jLabel8)
                                            .addComponent(jLabel9))
                                        .addGap(45, 45, 45)
                                        .addGroup(direkturLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(direkturLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addComponent(jTextField8, javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jTextField7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE))
                                            .addGroup(direkturLayout.createSequentialGroup()
                                                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(40, 40, 40)
                                                .addComponent(jButton1)))
                                        .addGap(20, 20, 20))))
                            .addGroup(direkturLayout.createSequentialGroup()
                                .addGap(197, 197, 197)
                                .addComponent(jButton2)
                                .addGap(18, 18, 18)
                                .addComponent(jButton3)
                                .addGap(18, 18, 18)
                                .addComponent(jButton4)
                                .addGap(18, 18, 18)
                                .addComponent(jButton5)))
                        .addGap(0, 122, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(direkturLayout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 636, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        direkturLayout.setVerticalGroup(
            direkturLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(direkturLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(direkturLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addGap(18, 18, 18)
                .addGroup(direkturLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(direkturLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(direkturLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(direkturLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(direkturLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(direkturLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(direkturLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(63, 63, 63)
                .addGroup(direkturLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2)
                    .addComponent(jButton3)
                    .addComponent(jButton4)
                    .addComponent(jButton5))
                .addGap(31, 31, 31)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(76, 76, 76)
                .addComponent(jButton6)
                .addContainerGap(52, Short.MAX_VALUE))
        );

        MainPanel.add(direktur, "card2");

        add(MainPanel, "card2");
    }// </editor-fold>//GEN-END:initComponents

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL untuk SELECT
    String query = "SELECT * FROM `sekertaris` WHERE id_sekertaris = ?";
    java.sql.PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dengan ID LPJ dari input
    preparedStatement.setString(1, jTextField9.getText().trim()); 

    // Menjalankan query
    ResultSet rs = preparedStatement.executeQuery();

    // Membuat model untuk JTable
    DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Sekertaris");
        tbl.addColumn("Nama");
        tbl.addColumn("Tanggal Lahir");
        tbl.addColumn("Nomor Telpon");
        tbl.addColumn("Email");
        tbl.addColumn("Gaji");
        tbl.addColumn("ID Surat Tugas");
        tbl.addColumn("ID Hasil Laporan");
        
        jTable2.setModel(tbl); 

    // Variabel untuk melacak apakah data ditemukan
    boolean dataFound = false;

    // Memasukkan data hasil query ke model tabel dan JTextField
    if (rs.next()) {
        dataFound = true;
        do {
        tbl.addRow(new Object[]{
        rs.getString("id_sekertaris"),
        rs.getString("nama"),
        rs.getString("tanggal_lahir"),
        rs.getString("nomor_telpon"),
        rs.getString("email"),
        rs.getString("gaji"),
        rs.getString("id_surat_tugas"),
        rs.getString("id_hasil_laporan"),
        });


            // Hanya ambil data untuk JTextField dari baris pertama
            if (tbl.getRowCount() == 1) {
                jTextField9.setText(rs.getString("id_sekertaris"));
                jTextField10.setText(rs.getString("nama"));
                jTextField11.setText(rs.getString("tanggal_lahir"));
                jTextField12.setText(rs.getString("nomor_telpon"));
                jTextField13.setText(rs.getString("email"));
                jTextField14.setText(rs.getString("gaji"));
                jTextField15.setText(rs.getString("id_surat_tugas"));
                jTextField16.setText(rs.getString("id_hasil_laporan"));
            }
        } while (rs.next());
    }

    // Menampilkan data pada JTable
    jTable2.setModel(tbl);

    // Menampilkan pesan jika data tidak ditemukan
    if (!dataFound) {
        JOptionPane.showMessageDialog(null, "Data tersebut tidak ditemukan.");
    } else {
        JOptionPane.showMessageDialog(null, "Data ditemukan!");
    }

    // Menutup resources
    rs.close();
    preparedStatement.close();
    conn.close();
} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL untuk INSERT
    String query = "INSERT INTO `sekertaris` (id_sekertaris, nama, tanggal_lahir, nomor_telpon, "
            + "email, gaji, id_surat_tugas, id_hasil_laporan) "
                 + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    
    // Mempersiapkan query
    java.sql.PreparedStatement preparedStatement = conn.prepareStatement(query);
    
    // Mengisi parameter query dengan nilai dari JTextField
    preparedStatement.setString(1, jTextField9.getText().trim()); // ID Sekertaris
    preparedStatement.setString(2, jTextField10.getText().trim()); // Nama
    preparedStatement.setString(3, jTextField11.getText().trim()); // Tanggal Lahir
    preparedStatement.setString(4, jTextField12.getText().trim()); // Nomor Telpon
    preparedStatement.setString(5, jTextField13.getText().trim()); // Email
    preparedStatement.setString(6, jTextField14.getText().trim()); // Gaji
    preparedStatement.setString(7, jTextField15.getText().trim()); // ID Surat Tugas
    preparedStatement.setString(8, jTextField16.getText().trim()); // ID Hasil Laporan

    // Menjalankan query INSERT
    int rowsInserted = preparedStatement.executeUpdate();
    
    // Menampilkan pesan berdasarkan hasil operasi
    if (rowsInserted > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil ditambahkan!");
    } else {
        JOptionPane.showMessageDialog(null, "Data gagal ditambahkan.");
    }

    // Menutup statement dan koneksi
    preparedStatement.close();
    conn.close();
} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}


    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL untuk UPDATE
    String query = "UPDATE `sekertaris` SET nama = ?, tanggal_lahir = ?, nomor_telpon = ?, "
            + "email = ?, gaji = ?, id_surat_tugas = ?, id_hasil_laporan = ? "
                 + "WHERE id_sekertaris = ?";
    
    // Mempersiapkan query
    java.sql.PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dengan nilai dari JTextField
    preparedStatement.setString(1, jTextField10.getText().trim()); // Nama
    preparedStatement.setString(2, jTextField11.getText().trim()); // Tanggal Lahir
    preparedStatement.setString(3, jTextField12.getText().trim()); // Nomor Telpon
    preparedStatement.setString(4, jTextField13.getText().trim()); // Email
    preparedStatement.setString(5, jTextField14.getText().trim()); // Gaji
    preparedStatement.setString(6, jTextField15.getText().trim()); // ID Surat Tugas
    preparedStatement.setString(7, jTextField16.getText().trim()); // ID Hasil Laporan
    preparedStatement.setString(8, jTextField9.getText().trim());  // ID Sekertaris (untuk WHERE)

    // Menjalankan query UPDATE
    int rowsUpdated = preparedStatement.executeUpdate();

    // Menampilkan pesan berdasarkan hasil operasi
    if (rowsUpdated > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil diperbarui!");
    } else {
        JOptionPane.showMessageDialog(null, "Data tidak ditemukan atau gagal diperbarui.");
    }

    // Menutup statement dan koneksi
    preparedStatement.close();
    conn.close();
} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}

    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL untuk DELETE
    String query = "DELETE FROM `sekertaris` WHERE id_sekertaris = ?";
    java.sql.PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dengan ID Direktur dari JTextField
    preparedStatement.setString(1, jTextField9.getText().trim()); 

    // Menjalankan query
    int rowsDeleted = preparedStatement.executeUpdate();

    // Menampilkan pesan jika data berhasil dihapus
    if (rowsDeleted > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
    } else {
        JOptionPane.showMessageDialog(null, "Data tidak ditemukan atau gagal dihapus.");
    }

    // Menutup resources
    preparedStatement.close();
    conn.close();
} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
    jTextField9.setText("");
    jTextField10.setText("");
    jTextField11.setText("");
    jTextField12.setText("");
    jTextField13.setText("");
    jTextField14.setText("");
    jTextField15.setText("");
    jTextField16.setText("");
    datasekertaris();
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
    MainPanel.removeAll();
    MainPanel.repaint();
    MainPanel.revalidate();
    
    MainPanel.add(bendahara);
    MainPanel.repaint();
    MainPanel.revalidate();
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
    MainPanel.removeAll();
    MainPanel.repaint();
    MainPanel.revalidate();
    
    MainPanel.add(direktur);
    MainPanel.repaint();
    MainPanel.revalidate();
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL untuk SELECT
    String query = "SELECT * FROM `bendahara` WHERE ID_Bendahara = ?";
    java.sql.PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dengan ID LPJ dari input
    preparedStatement.setString(1, jTextField17.getText().trim()); 

    // Menjalankan query
    ResultSet rs = preparedStatement.executeQuery();

    // Membuat model untuk JTable
    DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Bendahara");
        tbl.addColumn("Nama");
        tbl.addColumn("Email");
        tbl.addColumn("Nomor Telpon");
        tbl.addColumn("Tanggal Mulai Jabatan");
        tbl.addColumn("Saldo Keuangan");
        tbl.addColumn("Jumlah Transaksi");
        
        jTable3.setModel(tbl); 

    // Variabel untuk melacak apakah data ditemukan
    boolean dataFound = false;

    // Memasukkan data hasil query ke model tabel dan JTextField
    if (rs.next()) {
        dataFound = true;
        do {
        tbl.addRow(new Object[]{
        rs.getString("ID_Bendahara"),
        rs.getString("Nama_Bendahara"),
        rs.getString("Email_Bendahara"),
        rs.getString("Telepon_Bendahara"),
        rs.getString("Tanggal_Mulai_Jabatan"),
        rs.getString("Saldo_Keuangan"),
        rs.getString("Jumlah_Transaksi"),
        });


            // Hanya ambil data untuk JTextField dari baris pertama
            if (tbl.getRowCount() == 1) {
                jTextField17.setText(rs.getString("ID_Bendahara"));
                jTextField18.setText(rs.getString("Nama_Bendahara"));
                jTextField19.setText(rs.getString("Email_Bendahara"));
                jTextField20.setText(rs.getString("Telepon_Bendahara"));
                jTextField21.setText(rs.getString("Tanggal_Mulai_Jabatan"));
                jTextField22.setText(rs.getString("Saldo_Keuangan"));
                jTextField23.setText(rs.getString("Jumlah_Transaksi"));
            }
        } while (rs.next());
    }

    // Menampilkan data pada JTable
    jTable3.setModel(tbl);

    // Menampilkan pesan jika data tidak ditemukan
    if (!dataFound) {
        JOptionPane.showMessageDialog(null, "Data tersebut tidak ditemukan.");
    } else {
        JOptionPane.showMessageDialog(null, "Data ditemukan!");
    }

    // Menutup resources
    rs.close();
    preparedStatement.close();
    conn.close();
} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL untuk INSERT
    String query = "INSERT INTO `bendahara` (ID_Bendahara, Nama_Bendahara, Email_Bendahara, Telepon_Bendahara, Tanggal_Mulai_Jabatan, Saldo_Keuangan, Jumlah_Transaksi) "
                 + "VALUES (?, ?, ?, ?, ?, ?, ?)";
    
    // Mempersiapkan query
    java.sql.PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dengan nilai dari JTextField
    preparedStatement.setString(1, jTextField17.getText().trim()); // ID Bendahara
    preparedStatement.setString(2, jTextField18.getText().trim()); // Nama Bendahara
    preparedStatement.setString(3, jTextField19.getText().trim()); // Email Bendahara
    preparedStatement.setString(4, jTextField20.getText().trim()); // Telpon Bendahara
    preparedStatement.setString(5, jTextField21.getText().trim()); // Tanggal Mulai Jabatan
    preparedStatement.setString(6, jTextField22.getText().trim()); // Saldo Keuangan
    preparedStatement.setString(7, jTextField23.getText().trim()); // Jumlah Transaksi

    // Menjalankan query INSERT
    int rowsInserted = preparedStatement.executeUpdate();

    // Menampilkan pesan berdasarkan hasil operasi
    if (rowsInserted > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil ditambahkan!");
    } else {
        JOptionPane.showMessageDialog(null, "Data gagal ditambahkan.");
    }

    // Menutup statement dan koneksi
    preparedStatement.close();
    conn.close();
} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}

    }//GEN-LAST:event_jButton15ActionPerformed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL untuk UPDATE
    String query = "UPDATE `bendahara` SET Nama_Bendahara = ?, Email_Bendahara = ?, Telepon_Bendahara = ?, "
                 + "Tanggal_Mulai_Jabatan = ?, Saldo_Keuangan = ?, Jumlah_Transaksi = ? "
                 + "WHERE ID_Bendahara = ?";
    
    // Mempersiapkan query
    java.sql.PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dengan nilai dari JTextField
    preparedStatement.setString(1, jTextField18.getText().trim()); // Nama Bendahara
    preparedStatement.setString(2, jTextField19.getText().trim()); // Email Bendahara
    preparedStatement.setString(3, jTextField20.getText().trim()); // Telpon Bendahara
    preparedStatement.setString(4, jTextField21.getText().trim()); // Tanggal Mulai Jabatan
    preparedStatement.setString(5, jTextField22.getText().trim()); // Saldo Keuangan
    preparedStatement.setString(6, jTextField23.getText().trim()); // Jumlah Transaksi
    preparedStatement.setString(7, jTextField17.getText().trim()); // ID Bendahara (untuk WHERE)

    // Menjalankan query UPDATE
    int rowsUpdated = preparedStatement.executeUpdate();

    // Menampilkan pesan berdasarkan hasil operasi
    if (rowsUpdated > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil diperbarui!");
    } else {
        JOptionPane.showMessageDialog(null, "Data tidak ditemukan atau gagal diperbarui.");
    }

    // Menutup statement dan koneksi
    preparedStatement.close();
    conn.close();
} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}

    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL untuk DELETE
    String query = "DELETE FROM `bendahara` WHERE ID_Bendahara = ?";
    java.sql.PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dengan ID Direktur dari JTextField
    preparedStatement.setString(1, jTextField17.getText().trim()); 

    // Menjalankan query
    int rowsDeleted = preparedStatement.executeUpdate();

    // Menampilkan pesan jika data berhasil dihapus
    if (rowsDeleted > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
    } else {
        JOptionPane.showMessageDialog(null, "Data tidak ditemukan atau gagal dihapus.");
    }

    // Menutup resources
    preparedStatement.close();
    conn.close();
} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
    }//GEN-LAST:event_jButton17ActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
    jTextField17.setText("");
    jTextField18.setText("");
    jTextField19.setText("");
    jTextField20.setText("");
    jTextField21.setText("");
    jTextField22.setText("");
    jTextField23.setText("");
    databendahara();
    }//GEN-LAST:event_jButton18ActionPerformed

    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed
    MainPanel.removeAll();
    MainPanel.repaint();
    MainPanel.revalidate();
    
    MainPanel.add(pegawai);
    MainPanel.repaint();
    MainPanel.revalidate();
    }//GEN-LAST:event_jButton19ActionPerformed

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
    MainPanel.removeAll();
    MainPanel.repaint();
    MainPanel.revalidate();
    
    MainPanel.add(sekertaris);
    MainPanel.repaint();
    MainPanel.revalidate();
    }//GEN-LAST:event_jButton20ActionPerformed

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL untuk SELECT
    String query = "SELECT * FROM `pegawai` WHERE id_pegawai = ?";
    java.sql.PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dengan ID LPJ dari input
    preparedStatement.setString(1, jTextField24.getText().trim()); 

    // Menjalankan query
    ResultSet rs = preparedStatement.executeQuery();

    // Membuat model untuk JTable
    DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Pegawai");
        tbl.addColumn("Nama");
        tbl.addColumn("Tanggal Lahir");
        tbl.addColumn("Nomor Telpon");
        tbl.addColumn("Alamat");
        tbl.addColumn("Email");
        tbl.addColumn("Jabatan");
        tbl.addColumn("Status Surat Tugas");
        tbl.addColumn("ID Hasil Laporan");
        
        jTable4.setModel(tbl); 

    // Variabel untuk melacak apakah data ditemukan
    boolean dataFound = false;

    // Memasukkan data hasil query ke model tabel dan JTextField
    if (rs.next()) {
        dataFound = true;
        do {
        tbl.addRow(new Object[]{
        rs.getString("id_pegawai"),
        rs.getString("nama"),
        rs.getString("tanggal_lahir"),
        rs.getString("no_tlp"),
        rs.getString("alamat"),
        rs.getString("email"),
        rs.getString("jabatan"),
        rs.getString("status_surat_tugas"),
        rs.getString("id_hasil_laporan"),
        });


            // Hanya ambil data untuk JTextField dari baris pertama
            if (tbl.getRowCount() == 1) {
                jTextField24.setText(rs.getString("id_pegawai"));
                jTextField25.setText(rs.getString("nama"));
                jTextField26.setText(rs.getString("tanggal_lahir"));
                jTextField27.setText(rs.getString("no_tlp"));
                jTextField28.setText(rs.getString("alamat"));
                jTextField29.setText(rs.getString("email"));
                jTextField30.setText(rs.getString("jabatan"));
                jTextField31.setText(rs.getString("status_surat_tugas"));
                jTextField32.setText(rs.getString("id_hasil_laporan"));
                
            }
        } while (rs.next());
    }

    // Menampilkan data pada JTable
    jTable4.setModel(tbl);

    // Menampilkan pesan jika data tidak ditemukan
    if (!dataFound) {
        JOptionPane.showMessageDialog(null, "Data tersebut tidak ditemukan.");
    } else {
        JOptionPane.showMessageDialog(null, "Data ditemukan!");
    }

    // Menutup resources
    rs.close();
    preparedStatement.close();
    conn.close();
} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
    }//GEN-LAST:event_jButton21ActionPerformed

    private void jButton22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton22ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL untuk INSERT
    String query = "INSERT INTO `pegawai` (id_pegawai, nama, tanggal_lahir, no_tlp, alamat, email, jabatan, status_surat_tugas, id_hasil_laporan) " +
                   "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    java.sql.PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dengan data dari JTextField
    preparedStatement.setString(1, jTextField24.getText().trim()); // ID Pegawai
    preparedStatement.setString(2, jTextField25.getText().trim()); // Nama
    preparedStatement.setString(3, jTextField26.getText().trim()); // Tanggal Lahir
    preparedStatement.setString(4, jTextField27.getText().trim()); // Nomor Telepon
    preparedStatement.setString(5, jTextField28.getText().trim()); // Alamat
    preparedStatement.setString(6, jTextField29.getText().trim()); // Email
    preparedStatement.setString(7, jTextField30.getText().trim()); // Jabatan
    preparedStatement.setString(8, jTextField31.getText().trim()); // Status Surat Tugas
    preparedStatement.setString(9, jTextField32.getText().trim()); // ID Hasil Laporan

    // Menjalankan query INSERT
    int rowsInserted = preparedStatement.executeUpdate();

    // Menampilkan pesan berhasil jika data berhasil ditambahkan
    if (rowsInserted > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil ditambahkan!");
    }

    // Menutup resources
    preparedStatement.close();
    conn.close();
} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}

    }//GEN-LAST:event_jButton22ActionPerformed

    private void jButton23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton23ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL untuk UPDATE
    String query = "UPDATE `pegawai` SET " +
                   "nama = ?, tanggal_lahir = ?, no_tlp = ?, alamat = ?, email = ?, " +
                   "jabatan = ?, status_surat_tugas = ?, id_hasil_laporan = ? " +
                   "WHERE id_pegawai = ?";
    java.sql.PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dengan data dari JTextField
    preparedStatement.setString(1, jTextField25.getText().trim()); // Nama
    preparedStatement.setString(2, jTextField26.getText().trim()); // Tanggal Lahir
    preparedStatement.setString(3, jTextField27.getText().trim()); // Nomor Telepon
    preparedStatement.setString(4, jTextField28.getText().trim()); // Alamat
    preparedStatement.setString(5, jTextField29.getText().trim()); // Email
    preparedStatement.setString(6, jTextField30.getText().trim()); // Jabatan
    preparedStatement.setString(7, jTextField31.getText().trim()); // Status Surat Tugas
    preparedStatement.setString(8, jTextField32.getText().trim()); // ID Hasil Laporan
    preparedStatement.setString(9, jTextField24.getText().trim()); // ID Pegawai (WHERE)

    // Menjalankan query UPDATE
    int rowsUpdated = preparedStatement.executeUpdate();

    // Menampilkan pesan berhasil jika data berhasil diperbarui
    if (rowsUpdated > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil diperbarui!");
    } else {
        JOptionPane.showMessageDialog(null, "Data tidak ditemukan atau tidak diperbarui.");
    }

    // Menutup resources
    preparedStatement.close();
    conn.close();
} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}

    }//GEN-LAST:event_jButton23ActionPerformed

    private void jButton24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton24ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL untuk DELETE
    String query = "DELETE FROM `pegawai` WHERE id_pegawai = ?";
    java.sql.PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dengan ID Direktur dari JTextField
    preparedStatement.setString(1, jTextField24.getText().trim()); 

    // Menjalankan query
    int rowsDeleted = preparedStatement.executeUpdate();

    // Menampilkan pesan jika data berhasil dihapus
    if (rowsDeleted > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
    } else {
        JOptionPane.showMessageDialog(null, "Data tidak ditemukan atau gagal dihapus.");
    }

    // Menutup resources
    preparedStatement.close();
    conn.close();
} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
    }//GEN-LAST:event_jButton24ActionPerformed

    private void jButton25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton25ActionPerformed
    jTextField24.setText("");
    jTextField25.setText("");
    jTextField26.setText("");
    jTextField27.setText("");
    jTextField28.setText("");
    jTextField29.setText("");
    jTextField30.setText("");
    jTextField31.setText("");
    jTextField32.setText("");
    datapegawai();
    }//GEN-LAST:event_jButton25ActionPerformed

    private void jButton26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton26ActionPerformed
    MainPanel.removeAll();
    MainPanel.repaint();
    MainPanel.revalidate();
    
    MainPanel.add(admin);
    MainPanel.repaint();
    MainPanel.revalidate();
    }//GEN-LAST:event_jButton26ActionPerformed

    private void jButton27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton27ActionPerformed
    MainPanel.removeAll();
    MainPanel.repaint();
    MainPanel.revalidate();
    
    MainPanel.add(bendahara);
    MainPanel.repaint();
    MainPanel.revalidate();
    }//GEN-LAST:event_jButton27ActionPerformed

    private void jButton28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton28ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL untuk SELECT
    String query = "SELECT * FROM `admin` WHERE id_admin = ?";
    java.sql.PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dengan ID LPJ dari input
    preparedStatement.setString(1, jTextField33.getText().trim()); 

    // Menjalankan query
    ResultSet rs = preparedStatement.executeQuery();

    // Membuat model untuk JTable
    DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Admin");
        tbl.addColumn("Nama");
        tbl.addColumn("Alamat");
        tbl.addColumn("Email");
        tbl.addColumn("Tanggal Lahir");
        tbl.addColumn("Nomor Telpon");
        tbl.addColumn("Gaji");
        tbl.addColumn("NIK");
        
        jTable5.setModel(tbl); 

    // Variabel untuk melacak apakah data ditemukan
    boolean dataFound = false;

    // Memasukkan data hasil query ke model tabel dan JTextField
    if (rs.next()) {
        dataFound = true;
        do {
        tbl.addRow(new Object[]{
        rs.getString("id_pegawai"),
        rs.getString("nama"),
        rs.getString("alamat"),
        rs.getString("email"),
        rs.getString("tanggal_lahir"),
        rs.getString("no_telepon"),
        rs.getString("gaji"),
        rs.getString("nik"),
        });


            // Hanya ambil data untuk JTextField dari baris pertama
            if (tbl.getRowCount() == 1) {
                jTextField33.setText(rs.getString("id_pegawai"));
                jTextField34.setText(rs.getString("nama"));
                jTextField35.setText(rs.getString("alamat"));
                jTextField36.setText(rs.getString("email"));
                jTextField37.setText(rs.getString("tanggal_lahir"));
                jTextField38.setText(rs.getString("no_telepon"));
                jTextField39.setText(rs.getString("gaji"));
                jTextField40.setText(rs.getString("nik"));
                
            }
        } while (rs.next());
    }

    // Menampilkan data pada JTable
    jTable5.setModel(tbl);

    // Menampilkan pesan jika data tidak ditemukan
    if (!dataFound) {
        JOptionPane.showMessageDialog(null, "Data tersebut tidak ditemukan.");
    } else {
        JOptionPane.showMessageDialog(null, "Data ditemukan!");
    }

    // Menutup resources
    rs.close();
    preparedStatement.close();
    conn.close();
} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}
    }//GEN-LAST:event_jButton28ActionPerformed

    private void jButton29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton29ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL untuk INSERT
    String query = "INSERT INTO `admin` (id_admin, nama, alamat, email, tanggal_lahir, no_telepon, gaji, nik) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    java.sql.PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dengan data dari JTextField
    preparedStatement.setString(1, jTextField33.getText().trim()); // ID Admin
    preparedStatement.setString(2, jTextField34.getText().trim()); // Nama
    preparedStatement.setString(3, jTextField35.getText().trim()); // Alamat
    preparedStatement.setString(4, jTextField36.getText().trim()); // Email
    preparedStatement.setString(5, jTextField37.getText().trim()); // Tanggal Lahir
    preparedStatement.setString(6, jTextField38.getText().trim()); // Nomor Telepon
    preparedStatement.setString(7, jTextField39.getText().trim()); // Gaji
    preparedStatement.setString(8, jTextField40.getText().trim()); // NIK

    // Menjalankan query
    int rowsInserted = preparedStatement.executeUpdate();

    // Menampilkan pesan sukses atau gagal
    if (rowsInserted > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil ditambahkan!");
    } else {
        JOptionPane.showMessageDialog(null, "Data gagal ditambahkan!");
    }

    // Menutup resources
    preparedStatement.close();
    conn.close();
} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}

    }//GEN-LAST:event_jButton29ActionPerformed

    private void jButton30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton30ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL untuk UPDATE
    String query = "UPDATE `admin` SET nama = ?, alamat = ?, email = ?, tanggal_lahir = ?, no_telepon = ?, gaji = ?, nik = ? WHERE id_admin = ?";
    java.sql.PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dengan data dari JTextField
    preparedStatement.setString(1, jTextField34.getText().trim()); // Nama
    preparedStatement.setString(2, jTextField35.getText().trim()); // Alamat
    preparedStatement.setString(3, jTextField36.getText().trim()); // Email
    preparedStatement.setString(4, jTextField37.getText().trim()); // Tanggal Lahir
    preparedStatement.setString(5, jTextField38.getText().trim()); // Nomor Telepon
    preparedStatement.setString(6, jTextField39.getText().trim()); // Gaji
    preparedStatement.setString(7, jTextField40.getText().trim()); // NIK
    preparedStatement.setString(8, jTextField33.getText().trim()); // ID Admin (parameter WHERE)

    // Menjalankan query
    int rowsUpdated = preparedStatement.executeUpdate();

    // Menampilkan pesan sukses atau gagal
    if (rowsUpdated > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil diperbarui!");
    } else {
        JOptionPane.showMessageDialog(null, "Data dengan ID tersebut tidak ditemukan.");
    }

    // Menutup resources
    preparedStatement.close();
    conn.close();
} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}

    }//GEN-LAST:event_jButton30ActionPerformed

    private void jButton31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton31ActionPerformed
    try {
    // Membuat koneksi
    Connection conn = konektor.koneksiDB();

    // Membuat query SQL untuk DELETE
    String query = "DELETE FROM `admin` WHERE id_admin = ?";
    java.sql.PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Mengisi parameter query dengan data dari JTextField
    preparedStatement.setString(1, jTextField33.getText().trim()); // ID Admin

    // Menjalankan query
    int rowsDeleted = preparedStatement.executeUpdate();

    // Menampilkan pesan sukses atau gagal
    if (rowsDeleted > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
    } else {
        JOptionPane.showMessageDialog(null, "Data dengan ID tersebut tidak ditemukan.");
    }

    // Menutup resources
    preparedStatement.close();
    conn.close();
} catch (Exception e) {
    // Menangani error
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}

    }//GEN-LAST:event_jButton31ActionPerformed

    private void jButton32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton32ActionPerformed
    jTextField33.setText("");
    jTextField34.setText("");
    jTextField35.setText("");
    jTextField36.setText("");
    jTextField37.setText("");
    jTextField38.setText("");
    jTextField39.setText("");
    jTextField40.setText("");
    dataadmin();
    }//GEN-LAST:event_jButton32ActionPerformed

    private void jButton33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton33ActionPerformed
    MainPanel.removeAll();
    MainPanel.repaint();
    MainPanel.revalidate();
    
    MainPanel.add(direktur);
    MainPanel.repaint();
    MainPanel.revalidate();
    }//GEN-LAST:event_jButton33ActionPerformed

    private void jButton34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton34ActionPerformed
    MainPanel.removeAll();
    MainPanel.repaint();
    MainPanel.revalidate();
    
    MainPanel.add(pegawai);
    MainPanel.repaint();
    MainPanel.revalidate();
    }//GEN-LAST:event_jButton34ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        MainPanel.removeAll();
        MainPanel.repaint();
        MainPanel.revalidate();

        MainPanel.add(sekertaris);
        MainPanel.repaint();
        MainPanel.revalidate();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField4.setText("");
        jTextField5.setText("");
        jTextField6.setText("");
        jTextField7.setText("");
        jTextField8.setText("");
        datadirektur();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        try {
            // Membuat koneksi
            Connection conn = konektor.koneksiDB();

            // Membuat query SQL untuk DELETE
            String query = "DELETE FROM `direktur` WHERE id_direktur = ?";
            java.sql.PreparedStatement preparedStatement = conn.prepareStatement(query);

            // Mengisi parameter query dengan ID Direktur dari JTextField
            preparedStatement.setString(1, jTextField1.getText().trim()); // ID Direktur

            // Menjalankan query
            int rowsDeleted = preparedStatement.executeUpdate();

            // Menampilkan pesan jika data berhasil dihapus
            if (rowsDeleted > 0) {
                JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
            } else {
                JOptionPane.showMessageDialog(null, "Data tidak ditemukan atau gagal dihapus.");
            }

            // Menutup resources
            preparedStatement.close();
            conn.close();
        } catch (Exception e) {
            // Menangani error
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        try {
            // Membuat koneksi
            Connection conn = konektor.koneksiDB();

            // Membuat query SQL untuk UPDATE
            String query = "UPDATE `direktur` SET nama_direktur = ?, email = ?, tanggal_lahir = ?, alamat = ?, gaji = ?, "
                    + "nomor_telpon = ?, id_staff = ? WHERE id_direktur = ?";
            java.sql.PreparedStatement preparedStatement = conn.prepareStatement(query);

            // Mengisi parameter query dengan data dari JTextField
            preparedStatement.setString(1, jTextField2.getText().trim()); // Nama Direktur
            preparedStatement.setString(2, jTextField3.getText().trim()); // Email
            preparedStatement.setString(3, jTextField4.getText().trim()); // Tanggal Lahir
            preparedStatement.setString(4, jTextField5.getText().trim()); // Alamat
            preparedStatement.setString(5, jTextField6.getText().trim()); // Gaji
            preparedStatement.setString(6, jTextField7.getText().trim()); // Nomor Telpon
            preparedStatement.setString(7, jTextField8.getText().trim()); // ID Staff
            preparedStatement.setString(8, jTextField1.getText().trim()); // ID Direktur (digunakan sebagai kondisi WHERE)

            // Menjalankan query
            int rowsUpdated = preparedStatement.executeUpdate();

            // Menampilkan pesan jika data berhasil diperbarui
            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(null, "Data berhasil diperbarui!");
            } else {
                JOptionPane.showMessageDialog(null, "Data tidak ditemukan atau gagal diperbarui.");
            }

            // Menutup resources
            preparedStatement.close();
            conn.close();
        } catch (Exception e) {
            // Menangani error
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        try {
            // Membuat koneksi
            Connection conn = konektor.koneksiDB();

            // Membuat query SQL untuk INSERT
            String query = "INSERT INTO `direktur` (id_direktur, nama_direktur, email, tanggal_lahir, alamat, gaji, nomor_telpon, id_staff) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            java.sql.PreparedStatement preparedStatement = conn.prepareStatement(query);

            // Mengisi parameter query dengan data dari JTextField
            preparedStatement.setString(1, jTextField1.getText().trim()); // ID Direktur
            preparedStatement.setString(2, jTextField2.getText().trim()); // Nama Direktur
            preparedStatement.setString(3, jTextField3.getText().trim()); // Email
            preparedStatement.setString(4, jTextField4.getText().trim()); // Tanggal Lahir
            preparedStatement.setString(5, jTextField5.getText().trim()); // Alamat
            preparedStatement.setString(6, jTextField6.getText().trim()); // Gaji
            preparedStatement.setString(7, jTextField7.getText().trim()); // Nomor Telpon
            preparedStatement.setString(8, jTextField8.getText().trim()); // ID Staff

            // Menjalankan query
            int rowsInserted = preparedStatement.executeUpdate();

            // Menampilkan pesan jika data berhasil ditambahkan
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "Data berhasil ditambahkan!");
            } else {
                JOptionPane.showMessageDialog(null, "Data gagal ditambahkan.");
            }

            // Menutup resources
            preparedStatement.close();
            conn.close();
        } catch (Exception e) {
            // Menangani error
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            // Membuat koneksi
            Connection conn = konektor.koneksiDB();

            // Membuat query SQL untuk SELECT
            String query = "SELECT * FROM `direktur` WHERE id_direktur = ?";
            java.sql.PreparedStatement preparedStatement = conn.prepareStatement(query);

            // Mengisi parameter query dengan ID LPJ dari input
            preparedStatement.setString(1, jTextField1.getText().trim());

            // Menjalankan query
            ResultSet rs = preparedStatement.executeQuery();

            // Membuat model untuk JTable
            DefaultTableModel tbl = new DefaultTableModel();
            tbl.addColumn("ID Direktur");
            tbl.addColumn("Nama");
            tbl.addColumn("Email");
            tbl.addColumn("Tanggal Lahir");
            tbl.addColumn("Alamat");
            tbl.addColumn("Gaji");
            tbl.addColumn("Nomor Telpon");
            tbl.addColumn("ID Staff");

            // Variabel untuk melacak apakah data ditemukan
            boolean dataFound = false;

            // Memasukkan data hasil query ke model tabel dan JTextField
            if (rs.next()) {
                dataFound = true;
                do {
                    tbl.addRow(new Object[]{
                        rs.getString("id_direktur"),
                        rs.getString("nama_direktur"),
                        rs.getString("email"),
                        rs.getString("tanggal_lahir"),
                        rs.getString("alamat"),
                        rs.getString("gaji"),
                        rs.getString("nomor_telpon"),
                        rs.getString("id_staff"),
                    });

                    // Hanya ambil data untuk JTextField dari baris pertama
                    if (tbl.getRowCount() == 1) {
                        jTextField1.setText(rs.getString("id_direktur"));
                        jTextField2.setText(rs.getString("nama_direktur"));
                        jTextField3.setText(rs.getString("email"));
                        jTextField4.setText(rs.getString("tanggal_lahir"));
                        jTextField5.setText(rs.getString("alamat"));
                        jTextField6.setText(rs.getString("gaji"));
                        jTextField7.setText(rs.getString("nomor_telpon"));
                        jTextField8.setText(rs.getString("id_staff"));
                    }
                } while (rs.next());
            }

            // Menampilkan data pada JTable
            jTable1.setModel(tbl);

            // Menampilkan pesan jika data tidak ditemukan
            if (!dataFound) {
                JOptionPane.showMessageDialog(null, "Data tersebut tidak ditemukan.");
            } else {
                JOptionPane.showMessageDialog(null, "Data ditemukan!");
            }

            // Menutup resources
            rs.close();
            preparedStatement.close();
            conn.close();
        } catch (Exception e) {
            // Menangani error
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel MainPanel;
    private javax.swing.JPanel admin;
    private javax.swing.JPanel bendahara;
    private javax.swing.JPanel direktur;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton25;
    private javax.swing.JButton jButton26;
    private javax.swing.JButton jButton27;
    private javax.swing.JButton jButton28;
    private javax.swing.JButton jButton29;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton30;
    private javax.swing.JButton jButton31;
    private javax.swing.JButton jButton32;
    private javax.swing.JButton jButton33;
    private javax.swing.JButton jButton34;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable4;
    private javax.swing.JTable jTable5;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField16;
    private javax.swing.JTextField jTextField17;
    private javax.swing.JTextField jTextField18;
    private javax.swing.JTextField jTextField19;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField20;
    private javax.swing.JTextField jTextField21;
    private javax.swing.JTextField jTextField22;
    private javax.swing.JTextField jTextField23;
    private javax.swing.JTextField jTextField24;
    private javax.swing.JTextField jTextField25;
    private javax.swing.JTextField jTextField26;
    private javax.swing.JTextField jTextField27;
    private javax.swing.JTextField jTextField28;
    private javax.swing.JTextField jTextField29;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField30;
    private javax.swing.JTextField jTextField31;
    private javax.swing.JTextField jTextField32;
    private javax.swing.JTextField jTextField33;
    private javax.swing.JTextField jTextField34;
    private javax.swing.JTextField jTextField35;
    private javax.swing.JTextField jTextField36;
    private javax.swing.JTextField jTextField37;
    private javax.swing.JTextField jTextField38;
    private javax.swing.JTextField jTextField39;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField40;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JPanel pegawai;
    private javax.swing.JPanel sekertaris;
    // End of variables declaration//GEN-END:variables
}
